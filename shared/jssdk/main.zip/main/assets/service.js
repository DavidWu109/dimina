var service = (function() {
	//#region \0rolldown/runtime.js
	var __defProp = Object.defineProperty;
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	//#endregion
	//#region ../common/dist/common.js
	function isUnsafeProperty(key) {
		return key === "__proto__";
	}
	function isDeepKey(key) {
		switch (typeof key) {
			case "number":
			case "symbol": return false;
			case "string": return key.includes(".") || key.includes("[") || key.includes("]");
		}
	}
	function toKey(value) {
		if (typeof value === "string" || typeof value === "symbol") return value;
		if (Object.is(value?.valueOf?.(), -0)) return "-0";
		return String(value);
	}
	function toString(value) {
		if (value == null) return "";
		if (typeof value === "string") return value;
		if (Array.isArray(value)) return value.map(toString).join(",");
		const result = String(value);
		if (result === "0" && Object.is(Number(value), -0)) return "-0";
		return result;
	}
	function toPath(deepKey) {
		if (Array.isArray(deepKey)) return deepKey.map(toKey);
		if (typeof deepKey === "symbol") return [deepKey];
		deepKey = toString(deepKey);
		const result = [];
		const length = deepKey.length;
		if (length === 0) return result;
		let index = 0;
		let key = "";
		let quoteChar = "";
		let bracket = false;
		if (deepKey.charCodeAt(0) === 46) {
			result.push("");
			index++;
		}
		while (index < length) {
			const char = deepKey[index];
			if (quoteChar) if (char === "\\" && index + 1 < length) {
				index++;
				key += deepKey[index];
			} else if (char === quoteChar) quoteChar = "";
			else key += char;
			else if (bracket) if (char === "\"" || char === "'") quoteChar = char;
			else if (char === "]") {
				bracket = false;
				result.push(key);
				key = "";
			} else key += char;
			else if (char === "[") {
				bracket = true;
				if (key) {
					result.push(key);
					key = "";
				}
			} else if (char === ".") {
				if (key) {
					result.push(key);
					key = "";
				}
			} else key += char;
			index++;
		}
		if (key) result.push(key);
		return result;
	}
	function get$1(object, path, defaultValue) {
		if (object == null) return defaultValue;
		switch (typeof path) {
			case "string": {
				if (isUnsafeProperty(path)) return defaultValue;
				const result = object[path];
				if (result === void 0) if (isDeepKey(path)) return get$1(object, toPath(path), defaultValue);
				else return defaultValue;
				return result;
			}
			case "number":
			case "symbol": {
				if (typeof path === "number") path = toKey(path);
				const result = object[path];
				if (result === void 0) return defaultValue;
				return result;
			}
			default: {
				if (Array.isArray(path)) return getWithPath(object, path, defaultValue);
				if (Object.is(path?.valueOf(), -0)) path = "-0";
				else path = String(path);
				if (isUnsafeProperty(path)) return defaultValue;
				const result = object[path];
				if (result === void 0) return defaultValue;
				return result;
			}
		}
	}
	function getWithPath(object, path, defaultValue) {
		if (path.length === 0) return defaultValue;
		let current = object;
		for (let index = 0; index < path.length; index++) {
			if (current == null) return defaultValue;
			if (isUnsafeProperty(path[index])) return defaultValue;
			current = current[path[index]];
		}
		if (current === void 0) return defaultValue;
		return current;
	}
	function isObject(value) {
		return value !== null && (typeof value === "object" || typeof value === "function");
	}
	function isEqualsSameValueZero(value, other) {
		return value === other || Number.isNaN(value) && Number.isNaN(other);
	}
	var IS_UNSIGNED_INTEGER = /^(?:0|[1-9]\d*)$/;
	function isIndex(value, length = Number.MAX_SAFE_INTEGER) {
		switch (typeof value) {
			case "number": return Number.isInteger(value) && value >= 0 && value < length;
			case "symbol": return false;
			case "string": return IS_UNSIGNED_INTEGER.test(value);
		}
	}
	function isSymbol(value) {
		return typeof value === "symbol" || value instanceof Symbol;
	}
	var regexIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
	var regexIsPlainProp = /^\w*$/;
	function isKey(value, object) {
		if (Array.isArray(value)) return false;
		if (typeof value === "number" || typeof value === "boolean" || value == null || isSymbol(value)) return true;
		return typeof value === "string" && (regexIsPlainProp.test(value) || !regexIsDeepProp.test(value)) || object != null && Object.hasOwn(object, value);
	}
	var assignValue = (object, key, value) => {
		const objValue = object[key];
		if (!(Object.hasOwn(object, key) && isEqualsSameValueZero(objValue, value)) || value === void 0 && !(key in object)) object[key] = value;
	};
	function updateWith(obj, path, updater, customizer) {
		if (obj == null && !isObject(obj)) return obj;
		let resolvedPath;
		if (isKey(path, obj)) resolvedPath = [path];
		else if (Array.isArray(path)) resolvedPath = path;
		else resolvedPath = toPath(path);
		const updateValue = updater(get$1(obj, resolvedPath));
		let current = obj;
		for (let i = 0; i < resolvedPath.length && current != null; i++) {
			const key = toKey(resolvedPath[i]);
			if (isUnsafeProperty(key)) continue;
			let newValue;
			if (i === resolvedPath.length - 1) newValue = updateValue;
			else {
				const objValue = current[key];
				const customizerResult = customizer?.(objValue, key, obj);
				newValue = customizerResult !== void 0 ? customizerResult : isObject(objValue) ? objValue : isIndex(resolvedPath[i + 1]) ? [] : {};
			}
			assignValue(current, key, newValue);
			current = current[key];
		}
		return obj;
	}
	function set$1(obj, path, value) {
		return updateWith(obj, path, () => value, () => void 0);
	}
	function isFunction(value) {
		return typeof value === "function";
	}
	function isString(value) {
		return typeof value === "string";
	}
	function isNil(value) {
		return value === null || value === void 0;
	}
	function deepEqual(a, b) {
		if (a === b) return true;
		if (typeof a !== "object" || typeof b !== "object" || a == null || b == null) return false;
		const keysA = Object.keys(a);
		const keysB = Object.keys(b);
		if (keysA.length !== keysB.length) return false;
		return keysA.every((key) => deepEqual(a[key], b[key]));
	}
	function get(data, path) {
		return get$1(data, path);
	}
	function set(data, path, value) {
		set$1(data, path, value);
	}
	function uuid() {
		return Math.random().toString(36).slice(2, 7);
	}
	function toCamelCase(attr) {
		return attr.toLowerCase().replace(/-(.)/g, (_, group) => {
			return group.toUpperCase();
		});
	}
	function camelCaseToUnderscore(str) {
		return str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
	}
	var isBrowser = typeof window !== "undefined" && typeof navigator !== "undefined";
	isBrowser && /Android/i.test(navigator.userAgent);
	isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent);
	isBrowser && /OpenHarmony|harmony/.test(navigator.userAgent);
	isBrowser && /Android|iPad|iPhone|iPod|OpenHarmony|harmony|Mobile/.test(navigator.userAgent);
	var isWebWorker = (() => {
		if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) return true;
		else return false;
	})();
	function resolvePath(basePath, relativePath) {
		if (relativePath.startsWith("/")) return relativePath.slice(1);
		const currParts = basePath.split("/");
		const relativeParts = relativePath.split("/");
		for (const element of relativeParts) {
			const part = element;
			if (part === "..") {
				if (currParts.length > 0) currParts.pop();
			} else if (part !== "." && part !== "") currParts.push(part);
		}
		return currParts.join("/");
	}
	function parsePath(currPath, url) {
		const basePath = currPath.split("/").slice(0, -1).join("/");
		const parts = url.split("?");
		const pagePath = parts[0];
		const paramStr = parts[1];
		let newUrl = resolvePath(basePath, pagePath);
		if (paramStr) newUrl += `?${paramStr}`;
		return newUrl;
	}
	function suffixPixel(value) {
		return typeof value === "number" && Number.isFinite(value) && !Number.isNaN(value) ? `${value}px` : value;
	}
	/**
	* 高效的深拷贝实现
	* @param {*} value - 要拷贝的值
	* @returns {*} 拷贝后的值
	*/
	function cloneDeep(value) {
		if (value === null || typeof value !== "object") return value;
		const seen = /* @__PURE__ */ new WeakMap();
		function clone(item) {
			if (item === null || typeof item !== "object") return item;
			if (item instanceof Date) return new Date(item);
			if (item instanceof RegExp) return new RegExp(item.source, item.flags);
			if (Array.isArray(item)) {
				if (seen.has(item)) return seen.get(item);
				const arr = [];
				seen.set(item, arr);
				arr.push(...item.map(clone));
				return arr;
			}
			if (seen.has(item)) return seen.get(item);
			const obj = Object.create(Object.getPrototypeOf(item));
			seen.set(item, obj);
			return Object.assign(obj, ...Object.keys(item).map((key) => ({ [key]: clone(item[key]) })));
		}
		return clone(value);
	}
	var JSModules = {};
	var MODULES_STATUS_UNLOAD = 1;
	var MODULES_STATUS_LOADED = 2;
	function modDefine(id, factory) {
		if (!JSModules[id]) JSModules[id] = {
			factory,
			status: MODULES_STATUS_UNLOAD,
			exports: void 0
		};
	}
	function modRequire(id, callback, errorCallback) {
		if (typeof id !== "string") throw new TypeError("require args must be a string");
		const mod = JSModules[id];
		if (!mod) throw new Error(`module ${id} not found`);
		if (mod.status === MODULES_STATUS_UNLOAD) {
			mod.status = MODULES_STATUS_LOADED;
			const module = { exports: {} };
			let res;
			try {
				if (mod.factory) res = mod.factory.call(null, modRequire, module, module.exports);
			} catch (e) {
				mod.status = MODULES_STATUS_UNLOAD;
				const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
				console.error(`require ${id} error: ${em}`);
				if (isFunction(errorCallback)) errorCallback({
					mod: id,
					errMsg: e.message
				});
			}
			mod.exports = module.exports === void 0 ? res : module.exports;
		}
		if (isFunction(callback)) callback(mod.exports);
		return mod.exports;
	}
	modRequire.async = async (id) => {
		return new Promise((resolve, reject) => {
			try {
				resolve(modRequire(id));
			} catch (e) {
				reject(/* @__PURE__ */ new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
			}
		});
	};
	var Callback = class {
		constructor() {
			this.callbacks = {};
		}
		store(callback, keep, evtId = uuid()) {
			if (keep) {
				for (const [k, v] of Object.entries(this.callbacks)) if (v.callback === callback) return k;
			}
			this.callbacks[evtId] = {
				callback,
				keep
			};
			return evtId;
		}
		/**
		* [Container] triggerCallback -> [Service] invoke
		* @param {*} evtId
		* @param {*} args
		*/
		invoke(evtId, args) {
			if (evtId === void 0) return;
			const obj = this.callbacks[evtId];
			if (obj && isFunction(obj.callback)) {
				obj.callback(args);
				if (!obj.keep) delete this.callbacks[evtId];
			}
		}
		remove(evtId) {
			if (evtId) Object.keys(this.callbacks).forEach((k) => {
				if (evtId === k) delete this.callbacks[k];
			});
			else Object.entries(this.callbacks).forEach(([k, v]) => {
				if (v.keep) delete this.callbacks[k];
			});
		}
	};
	var callback_default = new Callback();
	//#endregion
	//#region src/core/host-env.js
	var HostEnv = class {
		constructor() {
			this.reset();
		}
		reset() {
			this.active = false;
			this.snapshot = {
				systemInfo: null,
				menuRect: null
			};
		}
		init(snapshot = {}) {
			this.active = true;
			this.snapshot = {
				...this.snapshot,
				...snapshot
			};
		}
		update(patch = {}) {
			this.snapshot = {
				...this.snapshot,
				...patch
			};
		}
		get(key) {
			if (!this.active) return null;
			return this.snapshot[key] ?? null;
		}
		getSystemInfo() {
			return this.get("systemInfo");
		}
		getMenuRect() {
			return this.get("menuRect");
		}
	};
	var host_env_default = new HostEnv();
	//#endregion
	//#region ../../node_modules/.pnpm/mitt@3.0.1/node_modules/mitt/dist/mitt.mjs
	function mitt_default(n) {
		return {
			all: n = n || /* @__PURE__ */ new Map(),
			on: function(t, e) {
				var i = n.get(t);
				i ? i.push(e) : n.set(t, [e]);
			},
			off: function(t, e) {
				var i = n.get(t);
				i && (e ? i.splice(i.indexOf(e) >>> 0, 1) : n.set(t, []));
			},
			emit: function(t, e) {
				var i = n.get(t);
				i && i.slice().map(function(n) {
					n(e);
				}), (i = n.get("*")) && i.slice().map(function(n) {
					n(t, e);
				});
			}
		};
	}
	var message_default = new class Message {
		constructor() {
			this.event = mitt_default();
			this.init();
		}
		init() {
			if (isWebWorker) globalThis.onmessage = (e) => {
				this.handleMsg(e.data);
			};
			else DiminaServiceBridge.onMessage = this.handleMsg.bind(this);
		}
		handleMsg(msg) {
			console.log("[service] receive msg: ", isWebWorker ? msg : JSON.stringify(msg));
			const { type, body } = msg;
			this.event.emit(type, body);
		}
		on(type, callback) {
			this.event.on(type, callback);
		}
		off(type) {
			this.event.off(type);
		}
		send(msg) {
			if (isWebWorker) Message.prototype.send = function(msg) {
				msg.method = "publish";
				globalThis.postMessage(msg);
			};
			else Message.prototype.send = function(msg) {
				return DiminaServiceBridge.publish(msg.body.bridgeId || "", msg);
			};
			return this.send(msg);
		}
		invoke(msg) {
			if (isWebWorker) Message.prototype.invoke = function(msg) {
				msg.method = "invoke";
				globalThis.postMessage(msg);
			};
			else Message.prototype.invoke = function(msg) {
				return DiminaServiceBridge.invoke(msg);
			};
			return this.invoke(msg);
		}
	}();
	//#endregion
	//#region src/core/router.js
	var Router = class {
		#stacks = [];
		#initId = "";
		setInitId(id) {
			this.#initId = id;
		}
		push(pageInfo, stackId) {
			this.stack(stackId).push(pageInfo);
		}
		pop() {
			if (this.stack().length > 0) this.stack().pop();
		}
		getPageInfo() {
			return this.stack().at(-1) || { id: this.#initId };
		}
		/**
		* 推入一个新页面栈
		*/
		pushStack(stackId) {
			const newStack = {
				id: stackId,
				pages: []
			};
			this.#stacks.push(newStack);
			return newStack;
		}
		/**
		* 当前新页面栈退出
		*/
		popStack(stackId) {
			if (stackId) {
				const index = this.#stacks.findIndex((stack) => stack.id === stackId);
				if (index !== -1) this.#stacks.splice(index, 1);
			} else if (this.#stacks.length > 0) this.#stacks.pop();
		}
		/**
		* 获取当前页面栈
		*/
		stack(stackId) {
			if (stackId) {
				let currentStack = this.#stacks.find((stack) => stack.id === stackId);
				if (!currentStack) currentStack = this.pushStack(stackId);
				return currentStack.pages;
			} else {
				const currentStack = this.#stacks.at(-1);
				if (currentStack) return currentStack.pages;
				else return this.pushStack(Date.now()).pages;
			}
		}
	};
	var router_default = new Router();
	//#endregion
	//#region src/api/common/index.js
	var hostEnvResolvers = {
		getWindowInfo: () => host_env_default.getSystemInfo(),
		getSystemInfoSync: () => host_env_default.getSystemInfo(),
		getAppBaseInfo: () => host_env_default.getSystemInfo(),
		getDeviceInfo: () => host_env_default.getSystemInfo(),
		getMenuButtonBoundingClientRect: () => host_env_default.getMenuRect()
	};
	function invokeAPI(name, data, target = "container") {
		const resolveFromHostEnv = hostEnvResolvers[name];
		if (target === "container" && resolveFromHostEnv) {
			const cachedValue = resolveFromHostEnv();
			if (cachedValue) return cachedValue;
		}
		let params;
		if (data === void 0 || typeof data === "string" || Array.isArray(data)) params = data;
		else if (isFunction(data)) params = { success: callback_default.store(data, true) };
		else {
			const { success, fail, complete, keep, evtId, ...rest } = data;
			params = rest;
			if (isFunction(success)) params.success = callback_default.store(success, keep, evtId);
			else params.success = success;
			if (isFunction(fail)) params.fail = callback_default.store(fail, keep, evtId);
			if (isFunction(complete)) params.complete = callback_default.store(complete, keep, evtId);
		}
		const msg = {
			type: "invokeAPI",
			target,
			body: {
				name,
				bridgeId: router_default.getPageInfo().id,
				params
			}
		};
		if (target === "container") return message_default.invoke(msg);
		else return message_default.send(msg);
	}
	//#endregion
	//#region src/api/core/route/index.js
	var route_exports = /* @__PURE__ */ __exportAll({
		navigateBack: () => navigateBack,
		navigateTo: () => navigateTo,
		reLaunch: () => reLaunch,
		redirectTo: () => redirectTo,
		switchTab: () => switchTab
	});
	/**
	* 跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.switchTab.html
	* @param {*} opts
	*/
	function switchTab(opts) {
		opts.url = parsePath(router_default.getPageInfo().route, opts.url);
		invokeAPI("switchTab", opts);
	}
	/**
	* 关闭所有页面，打开到应用内的某个页面
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.reLaunch.html
	* @param {*} opts
	*/
	function reLaunch(opts) {
		opts.url = parsePath(router_default.getPageInfo().route, opts.url);
		invokeAPI("reLaunch", opts);
	}
	/**
	* 关闭当前页面，跳转到应用内的某个页面。但是不允许跳转到 tabbar 页面。
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.redirectTo.html
	* @param {*} opts
	*/
	function redirectTo(opts) {
		const url = parsePath(router_default.getPageInfo().route, opts.url);
		if (router_default.getPageInfo().route === url) return;
		opts.url = url;
		invokeAPI("redirectTo", opts);
	}
	/**
	* 保留当前页面，跳转到应用内的某个页面。但是不能跳到 tabbar 页面
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.navigateTo.html
	* @param {*} opts
	*/
	function navigateTo(opts) {
		opts.url = parsePath(router_default.getPageInfo().route, opts.url);
		invokeAPI("navigateTo", opts);
	}
	/**
	* 关闭当前页面，返回上一页面或多级页面。可通过 getCurrentPages 获取当前的页面栈，决定需要返回几层。
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.navigateBack.html
	* @param {*} opts
	*/
	function navigateBack(opts) {
		invokeAPI("navigateBack", opts);
	}
	//#endregion
	//#region src/api/core/base/app-event/index.js
	var app_event_exports = /* @__PURE__ */ __exportAll({
		offAppHide: () => offAppHide,
		offAppShow: () => offAppShow,
		offError: () => offError,
		onAppHide: () => onAppHide,
		onAppRoute: () => onAppRoute,
		onAppShow: () => onAppShow,
		onError: () => onError,
		onPageNotFound: () => onPageNotFound,
		onUnhandledRejection: () => onUnhandledRejection
	});
	/**
	* 监听小程序错误事件。如脚本错误或 API 调用报错等。该事件与 App.onError 的回调时机与参数一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onError.html
	*/
	function onError(opts) {
		invokeAPI("onError", opts);
	}
	/**
	* 移除小程序错误事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.offError.html
	*/
	function offError(opts) {
		invokeAPI("offError", opts);
	}
	/**
	* 监听小程序切前台事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onAppShow.html
	*/
	function onAppShow(opts) {
		invokeAPI("onAppShow", opts);
	}
	/**
	* 监听小程序切后台事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onAppHide.html
	*/
	function onAppHide(opts) {
		invokeAPI("onAppHide", opts);
	}
	/**
	* 移除小程序切前台事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.offAppShow.html
	*/
	function offAppShow(opts) {
		invokeAPI("offAppShow", opts);
	}
	/**
	* 移除小程序切后台事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.offAppHide.html
	*/
	function offAppHide(opts) {
		invokeAPI("offAppHide", opts);
	}
	/**
	* 监听未处理的 Promise 拒绝事件。该事件与 App.onUnhandledRejection 的回调时机与参数一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onUnhandledRejection.html
	*/
	function onUnhandledRejection() {}
	/**
	* 监听小程序要打开的页面不存在事件。该事件与 App.onPageNotFound 的回调时机一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onPageNotFound.html
	*/
	function onPageNotFound() {}
	/**
	* 小程序隐藏API - onAppRoute(eventListener) | 微信开放社区
	* https://developers.weixin.qq.com/community/develop/article/doc/00006c80998d182690edbb60c56413
	*/
	function onAppRoute() {}
	//#endregion
	//#region src/api/core/base/index.js
	var base_exports = /* @__PURE__ */ __exportAll({
		canIUse: () => canIUse,
		env: () => env
	});
	/**
	* 文件系统
	* https://developers.weixin.qq.com/miniprogram/dev/framework/ability/file-system.html
	*
	* 环境变量
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/wx.env.html
	*/
	function env() {
		return { USER_DATA_PATH: "difile://" };
	}
	var builtInAPIs = new Set([
		"nextTick",
		"getUpdateManager",
		"getPerformance"
	]);
	/**
	* 判断小程序的API，回调，参数，组件等是否在当前版本可用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/wx.canIUse.html
	*/
	function canIUse(schema) {
		if (builtInAPIs.has(schema)) return true;
		try {
			return invokeAPI("canIUse", schema);
		} catch (error) {
			console.warn(`[canIUse] check ${schema} error:`, error);
			return false;
		}
	}
	//#endregion
	//#region src/api/core/base/performance/index.js
	var performance_exports = /* @__PURE__ */ __exportAll({ getPerformance: () => getPerformance });
	/**
	* 获取当前小程序性能相关的信息。关于小程序启动性能优化的更多内容，请参考启动性能指南。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/performance/wx.getPerformance.html
	*/
	function getPerformance() {
		return Performance.getInstance();
	}
	var Performance = class Performance {
		static #instance = null;
		constructor() {
			if (Performance.#instance) throw new Error("Cannot instantiate more than one Performance instance.");
			this.entryList = new EntryList();
			Performance.#instance = this;
		}
		static getInstance() {
			if (!Performance.#instance) Performance.#instance = new Performance();
			return Performance.#instance;
		}
		createObserver(listener) {
			const observer = new Observer(listener);
			if (listener) invokeAPI("addPerformanceObserver", { success: callback_default.store((res) => {
				const list = res?.data?.entryList && JSON.parse(res?.data?.entryList) || [];
				if (list) {
					this.entryList.push(list);
					observer.notify(list);
				}
			}, true) }, "render");
			return observer;
		}
		getEntries() {
			return this.entryList.getEntries();
		}
		getEntriesByName(name, entryType) {
			return this.entryList.getEntriesByName(name, entryType);
		}
		getEntriesByType(entryType) {
			return this.entryList.getEntriesByType(entryType);
		}
		setBufferSize(size) {
			this.entryList.maxEntrySize = size;
		}
	};
	var EntryList = class {
		constructor() {
			this._list = [];
			this.maxEntrySize = 30;
		}
		push(entries) {
			for (const entry of entries) {
				if (this._list.length >= this.maxEntrySize) this._list.shift();
				this._list.push(entry);
			}
		}
		getEntriesByName(name, entryType) {
			return this._entryFilter(name, entryType);
		}
		getEntriesByType(entryType) {
			return this._entryFilter(null, entryType);
		}
		_entryFilter(name, entryType) {
			return this._list.filter((entry) => {
				if (name && name !== entry.name) return false;
				if (entryType && entryType !== entry.entryType) return false;
				return true;
			});
		}
		getEntries() {
			return this._list;
		}
	};
	var Observer = class {
		constructor(callback) {
			this.entryTypes = [];
			this.callback = callback;
		}
		observe(options) {
			this.connected = true;
			this.entryTypes = options.entryTypes;
		}
		notify(data) {
			if (this.connected) {
				const entryList = new EntryList();
				entryList.push(data.filter((entry) => {
					let flag = false;
					if (this.entryTypes && this.entryTypes.length > 0) this.entryTypes.forEach((value) => {
						if (entry.entryType === value) flag = true;
					});
					return flag;
				}));
				this.callback(entryList);
			}
		}
		disconnect() {
			this.connected = false;
		}
	};
	//#endregion
	//#region src/api/core/base/subpackage/index.js
	var subpackage_exports = /* @__PURE__ */ __exportAll({
		loadSubpackage: () => loadSubpackage,
		preDownloadSubpackage: () => preDownloadSubpackage
	});
	/**
	* 触发分包预下载，只下载代码包，不自动执行代码
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/subpackage/wx.preDownloadSubpackage.html
	*/
	function preDownloadSubpackage(opts) {
		invokeAPI("preDownloadSubpackage", opts);
	}
	/**
	* 触发分包加载
	* https://developers.weixin.qq.com/minigame/dev/api/base/subpackage/wx.loadSubpackage.html
	*/
	function loadSubpackage(opts) {
		invokeAPI("loadSubpackage", opts);
	}
	//#endregion
	//#region src/api/core/base/system/index.js
	var system_exports = /* @__PURE__ */ __exportAll({
		getAppBaseInfo: () => getAppBaseInfo,
		getDeviceInfo: () => getDeviceInfo,
		getSystemInfo: () => getSystemInfo,
		getSystemInfoAsync: () => getSystemInfoAsync,
		getSystemInfoSync: () => getSystemInfoSync,
		getWindowInfo: () => getWindowInfo,
		openAppAuthorizeSetting: () => openAppAuthorizeSetting,
		openSystemBluetoothSetting: () => openSystemBluetoothSetting
	});
	/**
	* 跳转系统蓝牙设置页。仅支持安卓
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.openSystemBluetoothSetting.html
	*/
	function openSystemBluetoothSetting(opts) {
		invokeAPI("openSystemBluetoothSetting", opts);
	}
	/**
	* 获取窗口信息
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getWindowInfo.html
	*/
	function getWindowInfo(opts) {
		return invokeAPI("getWindowInfo", opts);
	}
	/**
	* 跳转系统授权管理页
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.openAppAuthorizeSetting.html
	*/
	function openAppAuthorizeSetting(opts) {
		invokeAPI("openAppAuthorizeSetting", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getSystemInfo.html
	*/
	function getSystemInfo(opts) {
		return new Promise((resolve) => {
			resolve(invokeAPI("getSystemInfo", opts));
		});
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getSystemInfoSync.html
	*/
	function getSystemInfoSync() {
		return invokeAPI("getSystemInfoSync");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getSystemInfoAsync.html
	*/
	function getSystemInfoAsync(opts) {
		invokeAPI("getSystemInfoAsync", opts);
	}
	function getAppBaseInfo() {
		return invokeAPI("getAppBaseInfo");
	}
	function getDeviceInfo() {
		return invokeAPI("getDeviceInfo");
	}
	//#endregion
	//#region src/api/core/base/update/index.js
	var update_exports = /* @__PURE__ */ __exportAll({ getUpdateManager: () => getUpdateManager });
	/**
	* 获取全局唯一的版本更新管理器，用于管理小程序更新。关于小程序的更新机制，可以查看运行机制文档。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/wx.getUpdateManager.html
	*/
	function getUpdateManager() {
		return UpdateManager.getInstance();
	}
	var UpdateManager = class UpdateManager {
		static #instance = null;
		constructor() {
			if (UpdateManager.#instance) throw new Error("Cannot instantiate more than one UpdateManager instance.");
			this.hasApplyUpdate = false;
			this.updateFailFlag = null;
			this.updateFailCbQueue = [];
			this.updateReadyCbQueue = [];
			this.updateReadyStatus = null;
			this.updateReadyFlag = false;
			this.updateStatus = null;
			this.updateStatusCbQueue = [];
			message_default.on("onUpdateStatusChange", (msg) => {
				const { event, strategy } = msg;
				if (event === "updatefail") {
					this.updateFailFlag = {};
					this.flashUpdateFailCb();
				} else if (event === "updateready") {
					this.updateReadyFlag = true;
					this.updateReadyStatus = { strategy };
					this.flushUpdateReadyCb();
				} else if (event === "noupdate") {
					this.updateStatus = { hasUpdate: true };
					this.flushUpdateStatusCb();
				} else if (event === "updating") {
					this.updateStatus = { hasUpdate: false };
					this.flushUpdateStatusCb();
				}
			});
			UpdateManager.#instance = this;
		}
		flashUpdateFailCb() {
			this.updateFailCbQueue.forEach((cb) => {
				typeof cb === "function" && cb();
			});
			this.updateFailCbQueue.length = 0;
		}
		flushUpdateStatusCb() {
			this.updateStatusCbQueue.forEach((cb) => {
				typeof cb === "function" && cb(this.updateStatus);
			});
			this.updateStatusCbQueue.length = 0;
		}
		flushUpdateReadyCb() {
			this.updateReadyCbQueue.forEach((cb) => {
				typeof cb === "function" && cb(this.updateReadyStatus);
			});
			this.updateReadyCbQueue.length = 0;
		}
		static getInstance() {
			if (!UpdateManager.#instance) UpdateManager.#instance = new UpdateManager();
			return UpdateManager.#instance;
		}
		/**
		* 强制小程序重启并使用新版本。在小程序新版本下载完成后（即收到 onUpdateReady 回调）调用。
		* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.applyUpdate.html
		*/
		applyUpdate() {
			if (this.updateReadyFlag && this.hasApplyUpdate) console.error("[applyUpdate]: applyUpdate has been called");
			else if (!this.updateReadyFlag) console.error("[applyUpdate]: update is not ready");
			else invokeAPI("applyUpdate");
		}
		/**
		* 监听向微信后台请求检查更新结果事件。微信在小程序每次启动（包括热启动）时自动检查更新，不需由开发者主动触发。
		* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onCheckForUpdate.html
		*/
		onCheckForUpdate(cb) {
			this.updateStatus ? typeof cb === "function" && cb(this.updateStatus) : this.updateStatusCbQueue.push(cb);
		}
		/**
		* 监听小程序更新失败事件。小程序有新版本，客户端主动触发下载（无需开发者触发），下载失败（可能是网络原因等）后回调
		* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateFailed.html
		*/
		onUpdateFailed(cb) {
			this.updateFailFlag ? typeof cb === "function" && cb(this.updateFailFlag) : this.updateFailCbQueue.push(cb);
		}
		/**
		* 监听小程序有版本更新事件。客户端主动触发下载（无需开发者触发），下载成功后回调
		*	https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateReady.html
		*/
		onUpdateReady(cb) {
			this.updateReadyFlag ? typeof cb === "function" && cb(this.updateReadyStatus) : this.updateReadyCbQueue.push(cb);
		}
	};
	//#endregion
	//#region src/api/core/camera/index.js
	var camera_exports = /* @__PURE__ */ __exportAll({ createCameraContext: () => createCameraContext });
	function createCameraContext() {
		return new CameraContext();
	}
	var CameraContext = class {
		constructor() {
			this.bridgeId = router_default.getPageInfo().id;
		}
		takePhoto(data) {
			invokeAPI("takePhoto", data);
		}
		startRecord() {
			invokeAPI("startRecord");
		}
		stopRecord() {
			invokeAPI("stopRecord");
		}
	};
	//#endregion
	//#region src/api/core/data-analysis/index.js
	var data_analysis_exports = /* @__PURE__ */ __exportAll({
		reportAnalytics: () => reportAnalytics,
		reportEvent: () => reportEvent
	});
	/**
	* 自定义分析数据上报接口。使用前，需要在小程序管理后台自定义分析中新建事件，配置好事件名与字段。
	* https://developers.weixin.qq.com/miniprogram/dev/api/data-analysis/wx.reportAnalytics.html
	*/
	function reportAnalytics(...opts) {
		invokeAPI("reportAnalytics", opts);
	}
	function reportEvent(eventId, data) {
		invokeAPI("reportAnalytics", {
			eventId,
			data
		});
	}
	//#endregion
	//#region src/api/core/device/bluetooth/index.js
	var bluetooth_exports = /* @__PURE__ */ __exportAll({
		closeBluetoothAdapter: () => closeBluetoothAdapter,
		getBluetoothAdapterState: () => getBluetoothAdapterState,
		getBluetoothDevices: () => getBluetoothDevices,
		getConnectedBluetoothDevices: () => getConnectedBluetoothDevices,
		offBluetoothAdapterStateChange: () => offBluetoothAdapterStateChange,
		offBluetoothDeviceFound: () => offBluetoothDeviceFound,
		onBluetoothAdapterStateChange: () => onBluetoothAdapterStateChange,
		onBluetoothDeviceFound: () => onBluetoothDeviceFound,
		openBluetoothAdapter: () => openBluetoothAdapter,
		startBluetoothDevicesDiscovery: () => startBluetoothDevicesDiscovery,
		stopBluetoothDevicesDiscovery: () => stopBluetoothDevicesDiscovery
	});
	/**
	* 停止搜寻附近的蓝牙外围设备。若已经找到需要的蓝牙设备并不需要继续搜索时，建议调用该接口停止蓝牙搜索。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.stopBluetoothDevicesDiscovery.html
	*/
	function stopBluetoothDevicesDiscovery(opts) {
		invokeAPI("stopBluetoothDevicesDiscovery", opts);
	}
	/**
	* 开始搜寻附近的蓝牙外围设备
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.startBluetoothDevicesDiscovery.html
	*/
	function startBluetoothDevicesDiscovery(opts) {
		invokeAPI("startBluetoothDevicesDiscovery", opts);
	}
	/**
	* 初始化蓝牙模块。iOS 上开启主机/从机（外围设备）模式时需分别调用一次，并指定对应的 mode。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.openBluetoothAdapter.html
	*/
	function openBluetoothAdapter(opts) {
		invokeAPI("openBluetoothAdapter", opts);
	}
	/**
	* 监听搜索到新设备的事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.onBluetoothDeviceFound.html
	*/
	function onBluetoothDeviceFound(opts) {
		invokeAPI("onBluetoothDeviceFound", opts);
	}
	/**
	* 监听蓝牙适配器状态变化事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.onBluetoothAdapterStateChange.html
	*/
	function onBluetoothAdapterStateChange(opts) {
		invokeAPI("onBluetoothAdapterStateChange", opts);
	}
	/**
	* 移除搜索到新设备的事件的全部监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.offBluetoothDeviceFound.html
	*/
	function offBluetoothDeviceFound() {
		invokeAPI("offBluetoothDeviceFound");
	}
	/**
	* 移除蓝牙适配器状态变化事件的全部监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.offBluetoothAdapterStateChange.html
	*/
	function offBluetoothAdapterStateChange() {
		invokeAPI("offBluetoothAdapterStateChange");
	}
	/**
	* 根据主服务 UUID 获取已连接的蓝牙设备
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.getConnectedBluetoothDevices.html
	*/
	function getConnectedBluetoothDevices(opts) {
		invokeAPI("getConnectedBluetoothDevices", opts);
	}
	/**
	* 获取在蓝牙模块生效期间所有搜索到的蓝牙设备。包括已经和本机处于连接状态的设备
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.getBluetoothDevices.html
	*/
	function getBluetoothDevices(opts) {
		invokeAPI("getBluetoothDevices", opts);
	}
	/**
	* 获取本机蓝牙适配器状态
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.getBluetoothAdapterState.html
	*/
	function getBluetoothAdapterState(opts) {
		invokeAPI("getBluetoothAdapterState", opts);
	}
	/**
	* 关闭蓝牙模块。调用该方法将断开所有已建立的连接并释放系统资源。建议在使用蓝牙流程后，与 wx.openBluetoothAdapter 成对调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.closeBluetoothAdapter.html
	*/
	function closeBluetoothAdapter(opts) {
		invokeAPI("closeBluetoothAdapter", opts);
	}
	//#endregion
	//#region src/api/core/device/bluetooth-ble/index.js
	var bluetooth_ble_exports = /* @__PURE__ */ __exportAll({
		closeBLEConnection: () => closeBLEConnection,
		createBLEConnection: () => createBLEConnection,
		getBLEDeviceCharacteristics: () => getBLEDeviceCharacteristics,
		getBLEDeviceRSSI: () => getBLEDeviceRSSI,
		getBLEDeviceServices: () => getBLEDeviceServices,
		notifyBLECharacteristicValueChange: () => notifyBLECharacteristicValueChange,
		offBLECharacteristicValueChange: () => offBLECharacteristicValueChange,
		offBLEConnectionStateChange: () => offBLEConnectionStateChange,
		onBLECharacteristicValueChange: () => onBLECharacteristicValueChange,
		onBLEConnectionStateChange: () => onBLEConnectionStateChange,
		readBLECharacteristicValue: () => readBLECharacteristicValue,
		setBLEMTU: () => setBLEMTU,
		writeBLECharacteristicValue: () => writeBLECharacteristicValue
	});
	/**
	* 向蓝牙低功耗设备特征值中写入二进制数据。注意：必须设备的特征支持 write 才可以成功调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.writeBLECharacteristicValue.html
	*/
	function writeBLECharacteristicValue(opts) {
		invokeAPI("writeBLECharacteristicValue", opts);
	}
	/**
	* 协商设置蓝牙低功耗的最大传输单元 (Maximum Transmission Unit, MTU)。需在 wx.createBLEConnection 调用成功后调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.setBLEMTU.html
	*/
	function setBLEMTU(opts) {
		invokeAPI("setBLEMTU", opts);
	}
	/**
	* 读取蓝牙低功耗设备特征值的二进制数据。注意：必须设备的特征支持 read 才可以成功调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.readBLECharacteristicValue.html
	*/
	function readBLECharacteristicValue(opts) {
		invokeAPI("readBLECharacteristicValue", opts);
	}
	/**
	* 监听蓝牙低功耗连接状态改变事件。包括开发者主动连接或断开连接，设备丢失，连接异常断开等等
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.onBLEConnectionStateChange.html
	*/
	function onBLEConnectionStateChange(opts) {
		invokeAPI("onBLEConnectionStateChange", opts);
	}
	/**
	* 监听蓝牙低功耗设备的特征值变化事件。必须先调用 wx.notifyBLECharacteristicValueChange 接口才能接收到设备推送的 notification。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.onBLECharacteristicValueChange.html
	*/
	function onBLECharacteristicValueChange(opts) {
		invokeAPI("onBLECharacteristicValueChange", opts);
	}
	/**
	* 移除蓝牙低功耗连接状态改变事件的监听函数。不传此参数则移除所有监听函数。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.offBLEConnectionStateChange.html
	*/
	function offBLEConnectionStateChange(opts) {
		invokeAPI("offBLEConnectionStateChange", opts);
	}
	/**
	* 移除蓝牙低功耗设备的特征值变化事件的全部监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.offBLECharacteristicValueChange.html
	*/
	function offBLECharacteristicValueChange() {
		invokeAPI("offBLECharacteristicValueChange");
	}
	/**
	* 启用蓝牙低功耗设备特征值变化时的 notify 功能，订阅特征。注意：必须设备的特征支持 notify 或者 indicate 才可以成功调用。
	* 另外，必须先启用 wx.notifyBLECharacteristicValueChange 才能监听到设备 characteristicValueChange 事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.notifyBLECharacteristicValueChange.html
	*/
	function notifyBLECharacteristicValueChange(opts) {
		invokeAPI("notifyBLECharacteristicValueChange", opts);
	}
	/**
	* 获取蓝牙低功耗设备所有服务 (service)。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.getBLEDeviceServices.html
	*/
	function getBLEDeviceServices(opts) {
		invokeAPI("getBLEDeviceServices", opts);
	}
	/**
	* 获取蓝牙低功耗设备的信号强度 (Received Signal Strength Indication, RSSI)
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.getBLEDeviceRSSI.html
	*/
	function getBLEDeviceRSSI(opts) {
		invokeAPI("getBLEDeviceRSSI", opts);
	}
	/**
	* 获取蓝牙低功耗设备某个服务中所有特征 (characteristic)。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.getBLEDeviceCharacteristics.html
	*/
	function getBLEDeviceCharacteristics(opts) {
		invokeAPI("getBLEDeviceCharacteristics", opts);
	}
	/**
	* 连接蓝牙低功耗设备。
	* 若小程序在之前已有搜索过某个蓝牙设备，并成功建立连接，可直接传入之前搜索获取的 deviceId 直接尝试连接该设备，无需再次进行搜索操作。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.createBLEConnection.html
	*/
	function createBLEConnection(opts) {
		invokeAPI("createBLEConnection", opts);
	}
	/**
	* 断开与蓝牙低功耗设备的连接。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.closeBLEConnection.html
	*/
	function closeBLEConnection(opts) {
		invokeAPI("closeBLEConnection", opts);
	}
	//#endregion
	//#region src/api/core/device/clipboard/index.js
	var clipboard_exports = /* @__PURE__ */ __exportAll({
		getClipboardData: () => getClipboardData,
		setClipboardData: () => setClipboardData
	});
	/**
	* 设置系统剪贴板的内容。调用成功后，会弹出 toast 提示"内容已复制"，持续 1.5s
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/clipboard/wx.setClipboardData.html
	*/
	function setClipboardData(opts) {
		invokeAPI("setClipboardData", opts);
	}
	/**
	* 获取系统剪贴板的内容
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/clipboard/wx.getClipboardData.html
	*/
	function getClipboardData(opts) {
		invokeAPI("getClipboardData", opts);
	}
	//#endregion
	//#region src/api/core/device/contact/index.js
	var contact_exports = /* @__PURE__ */ __exportAll({
		addPhoneContact: () => addPhoneContact,
		chooseContact: () => chooseContact
	});
	/**
	* 拉起手机通讯录，选择联系人
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/contact/wx.chooseContact.html
	*/
	function chooseContact(opts) {
		invokeAPI("chooseContact", opts);
	}
	/**
	* 添加手机通讯录联系人。用户可以选择将该表单以「新增联系人」或「添加到已有联系人」的方式，写入手机系统通讯录。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/contact/wx.addPhoneContact.html
	*/
	function addPhoneContact(opts) {
		invokeAPI("addPhoneContact", opts);
	}
	//#endregion
	//#region src/api/core/device/keyboard/index.js
	var keyboard_exports = /* @__PURE__ */ __exportAll({ hideKeyboard: () => hideKeyboard });
	/**
	* 在input、textarea等focus拉起键盘之后，手动调用此接口收起键盘
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/keyboard/wx.hideKeyboard.html
	*/
	function hideKeyboard(opts) {
		invokeAPI("hideKeyboard", opts);
	}
	//#endregion
	//#region src/api/core/device/memory/index.js
	var memory_exports = /* @__PURE__ */ __exportAll({
		offMemoryWarning: () => offMemoryWarning,
		onMemoryWarning: () => onMemoryWarning
	});
	/**
	* 监听内存不足告警事件。
	* 当 iOS/Android 向小程序进程发出内存警告时，触发该事件。触发该事件不意味小程序被杀，大部分情况下仅仅是告警，开发者可在收到通知后回收一些不必要资源避免进一步加剧内存紧张。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/memory/wx.onMemoryWarning.html
	*/
	function onMemoryWarning(opts) {
		invokeAPI("onMemoryWarning", opts);
	}
	/**
	* 移除内存不足告警事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/memory/wx.offMemoryWarning.html
	*/
	function offMemoryWarning(opts) {
		invokeAPI("offMemoryWarning", opts);
	}
	//#endregion
	//#region src/api/core/device/network/index.js
	var network_exports = /* @__PURE__ */ __exportAll({ getNetworkType: () => getNetworkType });
	/**
	* 获取网络类型
	*	https://developers.weixin.qq.com/miniprogram/dev/api/device/network/wx.getNetworkType.html
	* @param {*} opts
	*/
	function getNetworkType(opts) {
		invokeAPI("getNetworkType", opts);
	}
	//#endregion
	//#region src/api/core/device/phone/index.js
	var phone_exports = /* @__PURE__ */ __exportAll({ makePhoneCall: () => makePhoneCall });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/phone/wx.makePhoneCall.html
	*/
	function makePhoneCall(opts) {
		invokeAPI("makePhoneCall", opts);
	}
	//#endregion
	//#region src/api/core/device/scan/index.js
	var scan_exports = /* @__PURE__ */ __exportAll({ scanCode: () => scanCode });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/scan/wx.scanCode.html
	*/
	function scanCode(opts) {
		invokeAPI("scanCode", opts);
	}
	//#endregion
	//#region src/api/core/device/vibrate/index.js
	var vibrate_exports = /* @__PURE__ */ __exportAll({
		vibrateLong: () => vibrateLong,
		vibrateShort: () => vibrateShort
	});
	/**
	* 使手机发生较短时间的振动（15 ms）
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/vibrate/wx.vibrateShort.html
	*/
	function vibrateShort(opts) {
		invokeAPI("vibrateShort", opts);
	}
	/**
	* 使手机发生较长时间的振动（400 ms)
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/vibrate/wx.vibrateLong.html
	*/
	function vibrateLong(opts) {
		invokeAPI("vibrateLong", opts);
	}
	//#endregion
	//#region src/api/core/ext/index.js
	var ext_exports = /* @__PURE__ */ __exportAll({
		extBridge: () => extBridge,
		extOffBridge: () => extOffBridge,
		extOnBridge: () => extOnBridge,
		offLoginStatusChanged: () => offLoginStatusChanged,
		onLoginStatusChanged: () => onLoginStatusChanged
	});
	/**
	* 第三方拓展的 bridge 接口
	*/
	function extBridge({ event, module, data = {}, success, fail, complete }, extraCallback) {
		let overrideSuccess;
		let overrideFail;
		let overrideComplete;
		if (isFunction(extraCallback)) {
			overrideSuccess = extraCallback;
			overrideFail = extraCallback;
		} else {
			overrideSuccess = success;
			overrideFail = fail;
			overrideComplete = complete;
		}
		invokeAPI(event, {
			module,
			data,
			keep: data.isSustain ?? true,
			success: overrideSuccess,
			fail: overrideFail,
			complete: overrideComplete
		});
	}
	/**
	* 第三方扩展的 on 接口
	*/
	function extOnBridge({ event, module, callBack, isSustain = true }) {
		if (!module || module === "DMServiceBridgeModule") {
			console.error(`[ERROR]: extOnBridge \u53C2\u6570 module ${module ? `\u503C${module}\u4E0D\u5408\u6CD5` : "为空"}`);
			return;
		}
		if (!event) {
			console.error("[ERROR]: extOnBridge 参数 event 为空");
			return;
		}
		if (!callBack) {
			console.error("[ERROR]: extOnBridge 参数 callBack 为空");
			return;
		}
		const eventName = `${module}_${event}`;
		invokeAPI(eventName, {
			evtId: eventName,
			keep: isSustain,
			success: callBack
		});
	}
	/**
	* 第三方扩展的 off 接口
	*/
	function extOffBridge({ event, module, callBack }) {
		if (!module || module === "DMServiceBridgeModule") {
			console.error(`[ERROR]: extOffBridge \u53C2\u6570 module ${module ? `\u503C${module}\u4E0D\u5408\u6CD5` : "为空"}`);
			return;
		}
		if (!event) {
			console.error("[ERROR]: extOffBridge 参数 event 为空");
			return;
		}
		invokeAPI(`${module}_${event}`, { success: callBack });
	}
	/**
	* 登录状态变化时的回调
	*/
	function onLoginStatusChanged(callback) {
		message_default.on("notifyLoginStatusChanged", (msg) => {
			callback?.(msg);
		});
	}
	/**
	* 取消登录状态变化时的回调
	*/
	function offLoginStatusChanged() {
		message_default.off("notifyLoginStatusChanged");
	}
	//#endregion
	//#region src/api/core/file/index.js
	var file_exports = /* @__PURE__ */ __exportAll({ getFileSystemManager: () => getFileSystemManager });
	/**
	* 文件系统管理器
	* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.html
	*/
	var FileSystemManager = class {
		/**
		* 判断文件/目录是否存在
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.access.html
		*/
		access(opts) {
			invokeAPI("FileSystemManager.access", opts);
		}
		/**
		* 同步判断文件/目录是否存在
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.accessSync.html
		*/
		accessSync(path) {
			return invokeAPI("FileSystemManager.accessSync", path);
		}
		/**
		* 在文件结尾追加内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.appendFile.html
		*/
		appendFile(opts) {
			invokeAPI("FileSystemManager.appendFile", opts);
		}
		/**
		* 同步在文件结尾追加内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.appendFileSync.html
		*/
		appendFileSync(filePath, data, encoding) {
			return invokeAPI("FileSystemManager.appendFileSync", {
				filePath,
				data,
				encoding
			});
		}
		/**
		* 关闭文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.close.html
		*/
		close(opts) {
			invokeAPI("FileSystemManager.close", opts);
		}
		/**
		* 同步关闭文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.closeSync.html
		*/
		closeSync(opts) {
			return invokeAPI("FileSystemManager.closeSync", opts);
		}
		/**
		* 复制文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.copyFile.html
		*/
		copyFile(opts) {
			invokeAPI("FileSystemManager.copyFile", opts);
		}
		/**
		* 同步复制文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.copyFileSync.html
		*/
		copyFileSync(srcPath, destPath) {
			return invokeAPI("FileSystemManager.copyFileSync", {
				srcPath,
				destPath
			});
		}
		/**
		* 获取文件的状态信息
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.fstat.html
		*/
		fstat(opts) {
			invokeAPI("FileSystemManager.fstat", opts);
		}
		/**
		* 同步获取文件的状态信息
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.fstatSync.html
		*/
		fstatSync(opts) {
			return invokeAPI("FileSystemManager.fstatSync", opts);
		}
		/**
		* 对文件内容进行截断操作
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.ftruncate.html
		*/
		ftruncate(opts) {
			invokeAPI("FileSystemManager.ftruncate", opts);
		}
		/**
		* 对文件内容进行截断操作(同步)
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.ftruncateSync.html
		*/
		ftruncateSync(opts) {
			return invokeAPI("FileSystemManager.ftruncateSync", opts);
		}
		/**
		* 获取该小程序下的本地临时文件或本地缓存文件信息
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.getFileInfo.html
		*/
		getFileInfo(opts) {
			invokeAPI("FileSystemManager.getFileInfo", opts);
		}
		/**
		* 获取该小程序下已保存的本地缓存文件列表
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.getSavedFileList.html
		*/
		getSavedFileList(opts) {
			invokeAPI("FileSystemManager.getSavedFileList", opts);
		}
		/**
		* 创建目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.mkdir.html
		*/
		mkdir(opts) {
			invokeAPI("FileSystemManager.mkdir", opts);
		}
		/**
		* 同步创建目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.mkdirSync.html
		*/
		mkdirSync(dirPath, recursive) {
			return invokeAPI("FileSystemManager.mkdirSync", {
				dirPath,
				recursive
			});
		}
		/**
		* 打开文件,返回文件描述符
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.open.html
		*/
		open(opts) {
			invokeAPI("FileSystemManager.open", opts);
		}
		/**
		* 同步打开文件,返回文件描述符
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.openSync.html
		*/
		openSync(opts) {
			return invokeAPI("FileSystemManager.openSync", opts);
		}
		/**
		* 读文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.read.html
		*/
		read(opts) {
			invokeAPI("FileSystemManager.read", opts);
		}
		/**
		* 读文件(同步)
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readSync.html
		*/
		readSync(opts) {
			return invokeAPI("FileSystemManager.readSync", opts);
		}
		/**
		* 读取指定压缩类型的本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readCompressedFile.html
		*/
		readCompressedFile(opts) {
			invokeAPI("FileSystemManager.readCompressedFile", opts);
		}
		/**
		* 同步读取指定压缩类型的本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readCompressedFileSync.html
		*/
		readCompressedFileSync(opts) {
			return invokeAPI("FileSystemManager.readCompressedFileSync", opts);
		}
		/**
		* 读取目录内文件列表
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readdir.html
		*/
		readdir(opts) {
			invokeAPI("FileSystemManager.readdir", opts);
		}
		/**
		* 同步读取目录内文件列表
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readdirSync.html
		*/
		readdirSync(dirPath) {
			return invokeAPI("FileSystemManager.readdirSync", dirPath);
		}
		/**
		* 读取本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readFile.html
		*/
		readFile(opts) {
			invokeAPI("FileSystemManager.readFile", opts);
		}
		/**
		* 同步读取本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readFileSync.html
		*/
		readFileSync(filePath, encoding, position, length) {
			return invokeAPI("FileSystemManager.readFileSync", {
				filePath,
				encoding,
				position,
				length
			});
		}
		/**
		* 读取压缩包内的文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readZipEntry.html
		*/
		readZipEntry(opts) {
			invokeAPI("FileSystemManager.readZipEntry", opts);
		}
		/**
		* 删除该小程序下已保存的本地缓存文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.removeSavedFile.html
		*/
		removeSavedFile(opts) {
			invokeAPI("FileSystemManager.removeSavedFile", opts);
		}
		/**
		* 重命名文件。可以把文件从 oldPath 移动到 newPath
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.rename.html
		*/
		rename(opts) {
			invokeAPI("FileSystemManager.rename", opts);
		}
		/**
		* 同步重命名文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.renameSync.html
		*/
		renameSync(oldPath, newPath) {
			return invokeAPI("FileSystemManager.renameSync", {
				oldPath,
				newPath
			});
		}
		/**
		* 删除目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.rmdir.html
		*/
		rmdir(opts) {
			invokeAPI("FileSystemManager.rmdir", opts);
		}
		/**
		* 同步删除目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.rmdirSync.html
		*/
		rmdirSync(dirPath, recursive) {
			return invokeAPI("FileSystemManager.rmdirSync", {
				dirPath,
				recursive
			});
		}
		/**
		* 保存临时文件到本地
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.saveFile.html
		*/
		saveFile(opts) {
			invokeAPI("FileSystemManager.saveFile", opts);
		}
		/**
		* 同步保存临时文件到本地
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.saveFileSync.html
		*/
		saveFileSync(tempFilePath, filePath) {
			return invokeAPI("FileSystemManager.saveFileSync", {
				tempFilePath,
				filePath
			});
		}
		/**
		* 获取文件 Stats 对象
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.stat.html
		*/
		stat(opts) {
			invokeAPI("FileSystemManager.stat", opts);
		}
		/**
		* 同步获取文件 Stats 对象
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.statSync.html
		*/
		statSync(path, recursive) {
			return invokeAPI("FileSystemManager.statSync", {
				path,
				recursive
			});
		}
		/**
		* 对文件内容进行截断操作
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.truncate.html
		*/
		truncate(opts) {
			invokeAPI("FileSystemManager.truncate", opts);
		}
		/**
		* 对文件内容进行截断操作(同步)
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.truncateSync.html
		*/
		truncateSync(filePath, length) {
			return invokeAPI("FileSystemManager.truncateSync", {
				filePath,
				length
			});
		}
		/**
		* 删除文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.unlink.html
		*/
		unlink(opts) {
			invokeAPI("FileSystemManager.unlink", opts);
		}
		/**
		* 同步删除文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.unlinkSync.html
		*/
		unlinkSync(filePath) {
			return invokeAPI("FileSystemManager.unlinkSync", filePath);
		}
		/**
		* 解压文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.unzip.html
		*/
		unzip(opts) {
			invokeAPI("FileSystemManager.unzip", opts);
		}
		/**
		* 写入文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.write.html
		*/
		write(opts) {
			invokeAPI("FileSystemManager.write", opts);
		}
		/**
		* 同步写入文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.writeSync.html
		*/
		writeSync(opts) {
			return invokeAPI("FileSystemManager.writeSync", opts);
		}
		/**
		* 写文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.writeFile.html
		*/
		writeFile(opts) {
			invokeAPI("FileSystemManager.writeFile", opts);
		}
		/**
		* 同步写文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.writeFileSync.html
		*/
		writeFileSync(filePath, data, encoding) {
			return invokeAPI("FileSystemManager.writeFileSync", {
				filePath,
				data,
				encoding
			});
		}
	};
	var fileSystemManagerInstance = null;
	/**
	* 获取全局唯一的文件管理器
	* https://developers.weixin.qq.com/miniprogram/dev/api/file/wx.getFileSystemManager.html
	*/
	function getFileSystemManager() {
		if (!fileSystemManagerInstance) fileSystemManagerInstance = new FileSystemManager();
		return fileSystemManagerInstance;
	}
	//#endregion
	//#region src/instance/app/app.js
	var lifecycleMethods = [
		"onLaunch",
		"onShow",
		"onHide"
	];
	var reservedProperties = ["globalData"];
	var App = class {
		constructor(appModule, options) {
			this.appModule = appModule;
			this.options = options;
			this.init();
		}
		init() {
			this.initGlobalData();
			this.initLifecycle();
			this.initCustomMethods();
			this.invokeSomeLifecycle();
		}
		initGlobalData() {
			this.globalData = this.appModule.moduleInfo.globalData;
		}
		initLifecycle() {
			lifecycleMethods.forEach((method) => {
				const lifecycleMethod = this.appModule.moduleInfo[method];
				if (!isFunction(lifecycleMethod)) return;
				this[method] = lifecycleMethod.bind(this);
			});
		}
		initCustomMethods() {
			const moduleInfo = this.appModule.moduleInfo;
			for (const attr in moduleInfo) {
				if (lifecycleMethods.includes(attr) || reservedProperties.includes(attr)) continue;
				if (isFunction(moduleInfo[attr])) this[attr] = moduleInfo[attr].bind(this);
				else this[attr] = moduleInfo[attr];
			}
		}
		invokeSomeLifecycle() {
			this.onLaunch?.(this.options);
			this.onShow?.(this.options);
		}
		appShow() {
			this.onShow?.(this.options);
		}
		appHide() {
			this.onHide?.();
		}
	};
	//#endregion
	//#region src/api/core/wxml/selector-query/index.js
	var selector_query_exports = /* @__PURE__ */ __exportAll({ createSelectorQuery: () => createSelectorQuery });
	/**
	* 返回一个 SelectorQuery 对象实例。在自定义组件或包含自定义组件的页面中，应使用 this.createSelectorQuery() 来代替。
	* https://developers.weixin.qq.com/miniprogram/dev/framework/view/selector.html
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/wx.createSelectorQuery.html
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/SelectorQuery.html
	*/
	function createSelectorQuery() {
		return new SelectorQuery();
	}
	var SelectorQuery = class {
		constructor() {
			this.__componentId = router_default.getPageInfo().id;
			this.__taskQueue = [];
			this.__cbQueue = [];
		}
		/**
		* 将选择器的选取范围更改为自定义组件 component 内。（初始时，选择器仅选取页面范围的节点，不会选取任何自定义组件中的节点）。
		* @param {Component} com
		* @returns {SelectorQuery} SelectorQuery
		*/
		in(com) {
			this.__componentId = com.__id__;
			return this;
		}
		/**
		* 在当前页面下选择第一个匹配选择器 selector 的节点。返回一个 NodesRef 对象实例，可以用于获取节点信息。
		* @param {string} selector
		* @returns {NodesRef} NodesRef
		*/
		select(selector) {
			return new NodesRef(this, this.__componentId, selector, true);
		}
		/**
		* 在当前页面下选择匹配选择器 selector 的所有节点。
		* @param {string} selector
		* @returns {NodesRef} NodesRef
		*/
		selectAll(selector) {
			return new NodesRef(this, this.__componentId, selector, false);
		}
		/**
		* 选择显示区域。可用于获取显示区域的尺寸、滚动位置等信息。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/SelectorQuery.selectViewport.html
		* @returns {NodesRef} NodesRef
		*/
		selectViewport() {
			return new NodesRef(this, router_default.getPageInfo().id, "", true);
		}
		/**
		*
		* @param {*} selector
		* @param {*} moduleId
		* @param {*} single
		* @param {*} fields
		* @param {*} callback
		*/
		__push(selector, moduleId, single, fields, callback) {
			this.__taskQueue.push({
				moduleId,
				selector,
				single,
				fields
			});
			this.__cbQueue.push(callback);
		}
		/**
		* 执行所有的请求。请求结果按请求次序构成数组，在callback的第一个参数中返回。
		* @param {Function} callback
		*/
		exec(callback) {
			const self = this;
			invokeAPI("selectorQuery", {
				tasks: this.__taskQueue,
				success: (res) => {
					res.forEach((nodeInfo, index) => {
						const cb = self.__cbQueue[index];
						if (isFunction(cb)) cb.call(self, nodeInfo);
					});
					if (isFunction(callback)) callback.call(self, res);
				}
			}, "render");
		}
	};
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.html
	*/
	var NodesRef = class {
		constructor(selectorQuery, componentId, selector, single) {
			this.__selectorQuery = selectorQuery;
			this.__moduleId = componentId;
			this.__selector = selector;
			this.__single = single;
		}
		/**
		* 获取节点的相关信息。需要获取的字段在fields中指定。返回值是 nodesRef 对应的 selectorQuery
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.fields.html
		*/
		fields(fields, callback) {
			this.__selectorQuery.__push(this.__selector, this.__moduleId, this.__single, fields, callback);
			return this.__selectorQuery;
		}
		/**
		* 添加节点的布局位置的查询请求。相对于显示区域，以像素为单位。其功能类似于 DOM 的 getBoundingClientRect。返回 NodesRef 对应的 SelectorQuery
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.boundingClientRect.html
		*/
		boundingClientRect(callback) {
			return this.fields({
				id: true,
				dataset: true,
				rect: true,
				size: true
			}, callback);
		}
		/**
		* 添加节点的 Context 对象查询请求。
		* 目前支持 VideoContext、CanvasContext、LivePlayerContext、EditorContext和 MapContext 的获取。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.context.html
		*/
		context(callback) {
			return this.fields({ context: true }, callback);
		}
		/**
		* 获取 Node 节点实例
		* 目前支持 Canvas 和 ScrollViewContext 的获取。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.node.html
		*/
		node(callback) {
			return this.fields({ node: true }, callback);
		}
		/**
		* 添加节点的滚动位置查询请求。以像素为单位。节点必须是 scroll-view 或者 viewport，返回 NodesRef 对应的 SelectorQuery。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.scrollOffset.html
		*/
		scrollOffset(callback) {
			return this.fields({
				id: true,
				dataset: true,
				scrollOffset: true
			}, callback);
		}
	};
	//#endregion
	//#region src/api/core/wxml/intersection-observer/index.js
	var intersection_observer_exports = /* @__PURE__ */ __exportAll({ createIntersectionObserver: () => createIntersectionObserver });
	/**
	* 创建并返回一个 IntersectionObserver 对象实例。在自定义组件或包含自定义组件的页面中，应使用 this.createIntersectionObserver([options]) 来代替。
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/wx.createIntersectionObserver.html
	*/
	function createIntersectionObserver(component, options = {}) {
		const { thresholds = [0], initialRatio = 0, observeAll = false } = options;
		return new IntersectionObserver(component, {
			thresholds,
			initialRatio,
			observeAll
		});
	}
	var IntersectionObserver = class {
		constructor(component, options) {
			this._component = component;
			this._options = options;
			this._relativeInfo = [];
			this._observerId = null;
			this._disconnected = false;
		}
		/**
		* 使用选择器指定一个节点，作为参照区域之一
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeTo.html
		*/
		relativeTo(selector, margins = {
			left: 0,
			right: 0,
			top: 0,
			bottom: 0
		}) {
			if (this._observerId !== null) throw new Error("Relative nodes cannot be added after \"observe\" call in IntersectionObserver");
			this._relativeInfo.push({
				selector,
				margins: [
					"left",
					"right",
					"top",
					"bottom"
				].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
			});
			return this;
		}
		/**
		* 指定页面显示区域作为参照区域之一
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeToViewport.html
		*/
		relativeToViewport(margins = {
			left: 0,
			right: 0,
			top: 0,
			bottom: 0
		}) {
			if (this._observerId !== null) throw new Error("Relative nodes cannot be added after \"observe\" call in IntersectionObserver");
			this._relativeInfo.push({
				selector: null,
				margins: [
					"left",
					"right",
					"top",
					"bottom"
				].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
			});
			return this;
		}
		/**
		* 指定目标节点并开始监听相交状态变化情况
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.observe.html
		*/
		observe(targetSelector, listener) {
			const self = this;
			const id = callback_default.store((res) => {
				if (!self._disconnected) self._observerId = res.observerId;
				if (res.info) listener.call(self, res.info);
			}, true);
			invokeAPI("addIntersectionObserver", {
				moduleId: this._component.__id__,
				targetSelector,
				relativeInfo: this._relativeInfo,
				options: this._options,
				success: id
			}, "render");
		}
		/**
		* 停止监听。回调函数将不再触发
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.disconnect.html
		*/
		disconnect() {
			invokeAPI("removeIntersectionObserver", { observerId: this._observerId }, "render");
			this._disconnected = true;
		}
	};
	//#endregion
	//#region src/core/update-queue.js
	var queues = /* @__PURE__ */ new Map();
	function getQueue(bridgeId) {
		if (!queues.has(bridgeId)) queues.set(bridgeId, {
			depth: 0,
			scheduled: false,
			updates: [],
			byModuleId: /* @__PURE__ */ new Map(),
			callbackIds: []
		});
		return queues.get(bridgeId);
	}
	function createUpdateCallback(ctx, callbacks) {
		const callbackList = (Array.isArray(callbacks) ? callbacks : [callbacks]).filter(isFunction);
		if (callbackList.length === 0) return;
		return callback_default.store(() => {
			callbackList.forEach((cb) => cb.call(ctx));
		});
	}
	function beginUpdateBatch(bridgeId) {
		const queue = getQueue(bridgeId);
		queue.depth++;
	}
	function endUpdateBatch(bridgeId) {
		const queue = getQueue(bridgeId);
		if (queue.depth > 0) queue.depth--;
		if (queue.depth === 0) flushUpdates(bridgeId);
	}
	function enqueueUpdate(bridgeId, moduleId, data, callbackId) {
		const queue = getQueue(bridgeId);
		const update = queue.byModuleId.get(moduleId);
		if (update) Object.assign(update.data, data);
		else {
			const nextUpdate = {
				moduleId,
				data: { ...data }
			};
			queue.byModuleId.set(moduleId, nextUpdate);
			queue.updates.push(nextUpdate);
		}
		if (callbackId) queue.callbackIds.push(callbackId);
		if (queue.depth === 0 && !queue.scheduled) {
			queue.scheduled = true;
			Promise.resolve().then(() => {
				queue.scheduled = false;
				if (queue.depth === 0) flushUpdates(bridgeId);
			});
		}
	}
	function flushUpdates(bridgeId) {
		const queue = queues.get(bridgeId);
		if (!queue || queue.updates.length === 0) return;
		const updates = queue.updates;
		const callbackIds = queue.callbackIds;
		queue.updates = [];
		queue.byModuleId = /* @__PURE__ */ new Map();
		queue.callbackIds = [];
		queue.scheduled = false;
		message_default.send({
			type: "ub",
			target: "render",
			body: {
				bridgeId,
				updates,
				callbackIds
			}
		});
	}
	//#endregion
	//#region src/core/utils.js
	/**
	* 将 computed 的 key 提前写入 data，确保渲染层初始化时能正确追踪这些 key 的响应式依赖。
	*
	* 背景：渲染层 setup() 收到 initData 后才首次渲染，若 computed key 不在 initData 里，
	* 渲染函数第一次执行时访问该 key 拿到 undefined，Vue 不会建立依赖，后续值更新也不会触发重渲染。
	*
	* computed 经框架（如 mpx）的 filterOptions 处理后不会出现在 moduleInfo 里，
	* 只能在实例初始化完成后从框架运行时读取。目前通过 __mpxProxy 访问，
	* 后续若框架侧暴露标准字段（如 moduleInfo.__computedKeys），可在此替换为更通用的读取方式。
	*/
	function addComputedData(self) {
		const computed = self.__mpxProxy?.options?.computed;
		if (computed) {
			for (const ck of Object.keys(computed)) if (!Object.hasOwn(self.data, ck)) self.data[ck] = null;
		}
	}
	function filterData(obj) {
		if (isNil(obj)) return obj;
		return Object.entries(obj).reduce((acc, [key, value]) => {
			if (key.startsWith("$")) return acc;
			else if (isFunction(value)) {
				console.warn("[service] 值不支持函数引用", key);
				return acc;
			} else if (Array.isArray(value)) acc[key] = value.map((item) => {
				if (typeof item === "object" && item !== null) {
					if (item instanceof Date) return item.getTime();
					return filterData(item);
				}
				return item;
			});
			else if (value && typeof value === "object" && !Array.isArray(value)) if (value instanceof Date) acc[key] = value.getTime();
			else acc[key] = filterData(value);
			else acc[key] = value;
			return acc;
		}, {});
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html
	*
	* @param {{type, optionalTypes, value, observer}} properties
	*/
	function serializeProps(properties) {
		if (properties) {
			const props = {};
			for (const key in properties) {
				const item = properties[key];
				props[key] = props[key] || {};
				const transType = item && typeof item === "object" && Object.hasOwn(item, "type") ? convertToStringType(item.type) : convertToStringType(item);
				let array = null;
				if (Array.isArray(transType)) array = [...transType];
				else array = [transType];
				if (item && item.optionalTypes) {
					const oTransType = convertToStringType(item.optionalTypes);
					if (Array.isArray(oTransType)) array = [...oTransType];
					else array.push(oTransType);
				}
				props[key].type = array;
				if (props[key].type.length > 0) {
					if (item && isFunction(item.value)) props[key].default = item.value();
					else if (item) props[key].default = item.value;
				}
			}
			return props;
		}
	}
	var TYPE_TO_STRING_MAP = new Map([
		[String, "s"],
		[Number, "n"],
		[Boolean, "b"],
		[Object, "o"],
		[Array, "a"],
		[Function, "f"]
	]);
	/**
	* 属性的类型可以为 String Number Boolean Object Array 其一，也可以为 null 表示不限制类型。
	* 将实际类型转换成字符串方便传输
	* @param {*} type
	*/
	function convertToStringType(type) {
		if (Array.isArray(type)) return type.map((item) => convertToStringType(item));
		else {
			if (type === null || type === "") return null;
			const stringType = TYPE_TO_STRING_MAP.get(type);
			if (stringType) return stringType;
			console.warn(`[service] ignore unknown props type ${type}`);
			return null;
		}
	}
	/**
	* 在一次 setData 中，遍历所有变化的 key 并触发 observers，保证每个 observer 最多触发一次
	* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/observer.html
	* @param {string[]} changedKeys 本次 setData 变化的所有 key
	* @param {object} observers 组件定义的 observers 对象
	* @param {object} data 更新后的完整数据
	* @param {object} ctx 组件实例（this）
	* @param {object} oldValues 各 key 的旧值 { key: oldVal }
	*/
	function invokeObserversOnce(changedKeys, observers, data, ctx, oldValues) {
		const triggered = /* @__PURE__ */ new Set();
		for (const changedKey of changedKeys) for (const observerKey in observers) {
			if (triggered.has(observerKey)) continue;
			const keys = observerKey.split(",").map((k) => k.trim());
			if (keys.includes(changedKey)) {
				triggered.add(observerKey);
				const observerFn = observers[observerKey];
				const args = keys.map((key) => get(data, key));
				if (keys.length === 1) observerFn.call(ctx, ...args, oldValues[changedKey]);
				else observerFn.call(ctx, ...args);
				continue;
			}
			if (observerKey === "**") {
				triggered.add(observerKey);
				observers[observerKey].call(ctx, data);
				continue;
			}
			const observerKeyParts = observerKey.split(".");
			const changedKeyParts = changedKey.split(".");
			let matched = true;
			for (let i = 0; i < observerKeyParts.length; i++) if (observerKeyParts[i] === "**" || changedKeyParts[i] === void 0) break;
			else if (observerKeyParts[i] !== changedKeyParts[i]) {
				matched = false;
				break;
			}
			if (matched && observerKeyParts.length > 1) {
				triggered.add(observerKey);
				let targetData = data;
				for (const part of observerKeyParts) if (part !== "**") targetData = targetData?.[part];
				if (observerKey === changedKey) observers[observerKey].call(ctx, targetData, oldValues[changedKey]);
				else observers[observerKey].call(ctx, targetData);
			}
		}
	}
	/**
	* 触发数据监听器，一次 setData 最多触发每个监听器一次
	* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/observer.html
	* @param {*} changedKey
	* @param {*} observers
	* @param {*} data
	* @param {*} ctx
	* @param {*} oldVal
	*/
	function filterInvokeObserver(changedKey, observers, data, ctx, oldVal) {
		for (const observerKey in observers) {
			const observerFn = observers[observerKey];
			const keys = observerKey.split(",").map((k) => k.trim());
			if (keys.includes(changedKey)) {
				const args = keys.map((key) => get(data, key));
				if (keys.length === 1 && keys[0] === changedKey) observerFn.call(ctx, ...args, oldVal);
				else observerFn.call(ctx, ...args);
				continue;
			}
			if (observerKey === "**") {
				observerFn.call(ctx, data);
				continue;
			}
			const observerKeyParts = observerKey.split(".");
			const changedKeyParts = changedKey.split(".");
			let matched = true;
			for (let i = 0; i < observerKeyParts.length; i++) if (observerKeyParts[i] === "**" || changedKeyParts[i] === void 0) break;
			else if (observerKeyParts[i] !== changedKeyParts[i]) {
				matched = false;
				break;
			}
			if (matched) {
				let targetData = data;
				for (const part of observerKeyParts) if (part !== "**") targetData = targetData[part];
				if (observerKey === changedKey) observerFn.call(ctx, targetData, oldVal);
				else observerFn.call(ctx, targetData);
				continue;
			}
			const arrayMatch = observerKey.match(/^(.+)\[(\d+)\]$/);
			if (arrayMatch) {
				const arrayKey = arrayMatch[1];
				const index = Number.parseInt(arrayMatch[2], 10);
				if (arrayKey === changedKey.split("[")[0] && data[arrayKey] && data[arrayKey][index] !== void 0) {
					observerFn.call(ctx, data[arrayKey][index]);
					continue;
				}
			}
			if (changedKey.startsWith(observerKey)) {
				const targetData = observerKey.split(".").reduce((acc, key) => acc && acc[key], data);
				if (targetData !== void 0) {
					observerFn.call(ctx, targetData);
					continue;
				}
			}
		}
	}
	function resolveEventHandler(eventAttr = {}, type = "") {
		const normalizedType = type.trim();
		if (!normalizedType) return;
		const compactType = normalizedType.replace(/-/g, "").toLowerCase();
		const candidates = [
			normalizedType,
			toCamelCase(normalizedType),
			camelCaseToUnderscore(normalizedType),
			compactType
		];
		for (const candidate of candidates) if (candidate && eventAttr[candidate] !== void 0) return eventAttr[candidate];
	}
	function invokeBehaviorObservers(ctx, changedKeys, oldValues) {
		const info = ctx.__info__ || {};
		if (!info.behaviorObservers) return;
		for (const observerKey in info.behaviorObservers) {
			const observers = info.behaviorObservers[observerKey];
			if (!Array.isArray(observers) || observers.length === 0) continue;
			for (const changedKey of changedKeys) observers.forEach((observer) => {
				filterInvokeObserver(changedKey, { [observerKey]: observer }, ctx.data, ctx, oldValues[changedKey]);
			});
		}
	}
	function invokePropertyObservers(ctx, changedKeys, oldValues) {
		runPropertyObservers(ctx, changedKeys, oldValues);
	}
	function collectPropertyObservers(ctx, changedKeys, oldValues) {
		const propertyObserversToExecute = [];
		for (const prop of changedKeys) {
			const observer = ctx.__info__.properties?.[prop]?.observer;
			const val = ctx.data[prop];
			const oldVal = oldValues[prop];
			if (isString(observer)) propertyObserversToExecute.push(() => ctx[observer]?.(val, oldVal));
			else if (isFunction(observer)) propertyObserversToExecute.push(() => observer.call(ctx, val, oldVal));
		}
		return propertyObserversToExecute;
	}
	function runPropertyObservers(ctx, changedKeys, oldValues) {
		collectPropertyObservers(ctx, changedKeys, oldValues).reverse().forEach((run) => run());
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/behaviors.html
	* 
	* 同名字段的覆盖和组合规则：
	* 1. properties 和 methods: 组件覆盖 behavior, 靠后的 behavior 覆盖靠前的, 引用者覆盖被引用者
	* 2. data: 对象类型深度合并, 其他类型按优先级覆盖
	* 3. 生命周期和 observers: 不覆盖, 按顺序执行 (被引用的 > 引用者 > 靠前的 > 靠后的)
	* 4. 同一个 behavior 被多次引用时不会重复执行
	* 
	* @param {*} obj
	* @param {*} behaviors
	*/
	function mergeBehaviors(obj, behaviors) {
		if (!Array.isArray(behaviors)) return;
		const processedBehaviors = /* @__PURE__ */ new WeakMap();
		/**
		* 深度合并对象类型的 data 字段
		* @param {object} target 目标对象
		* @param {object} source 源对象
		* @returns {object} 合并后的对象
		*/
		function deepMergeData(target, source) {
			const result = { ...target };
			for (const key in source) if (Object.hasOwn(source, key)) {
				const targetValue = result[key];
				const sourceValue = source[key];
				if (targetValue && typeof targetValue === "object" && !Array.isArray(targetValue) && sourceValue && typeof sourceValue === "object" && !Array.isArray(sourceValue)) result[key] = deepMergeData(targetValue, sourceValue);
				else result[key] = sourceValue;
			}
			return result;
		}
		/**
		* 递归合并单个 behavior
		* @param {object} target 目标对象
		* @param {object} behavior behavior 对象
		*/
		function merge(target, behavior) {
			if (typeof behavior === "string") {
				handleBuiltinBehavior(target, behavior);
				return;
			}
			if (!behavior || typeof behavior !== "object") return;
			if (processedBehaviors.has(behavior)) return;
			processedBehaviors.set(behavior, true);
			if (Array.isArray(behavior.behaviors)) behavior.behaviors.forEach((b) => merge(target, b));
			if (behavior.properties) target.properties = {
				...behavior.properties,
				...target.properties
			};
			if (behavior.data) {
				if (!target.data) target.data = {};
				target.data = deepMergeData(behavior.data, target.data);
			}
			const lifetimes = [
				"created",
				"attached",
				"ready",
				"detached"
			];
			target.behaviorLifetimes = target.behaviorLifetimes || {};
			for (const lifetime of lifetimes) if (isFunction(behavior[lifetime])) {
				target.behaviorLifetimes[lifetime] = target.behaviorLifetimes[lifetime] || [];
				target.behaviorLifetimes[lifetime].push(behavior[lifetime]);
			}
			if (behavior.observers) {
				target.behaviorObservers = target.behaviorObservers || {};
				for (const observerKey in behavior.observers) {
					if (!target.behaviorObservers[observerKey]) target.behaviorObservers[observerKey] = [];
					target.behaviorObservers[observerKey].push(behavior.observers[observerKey]);
				}
			}
			if (behavior.methods) target.methods = {
				...behavior.methods,
				...target.methods
			};
			if (behavior.relations) target.relations = {
				...target.relations,
				...behavior.relations
			};
			if (behavior.export) target.export = behavior.export;
			if (behavior.pageLifetimes) {
				target.behaviorPageLifetimes = target.behaviorPageLifetimes || {};
				for (const lifetime of [
					"show",
					"hide",
					"resize",
					"routeDone"
				]) if (isFunction(behavior.pageLifetimes[lifetime])) {
					target.behaviorPageLifetimes[lifetime] = target.behaviorPageLifetimes[lifetime] || [];
					target.behaviorPageLifetimes[lifetime].push(behavior.pageLifetimes[lifetime]);
				}
			}
		}
		/**
		* 处理内置 behavior
		* @param {object} target 目标对象
		* @param {string} behaviorName behavior 名称
		*/
		function handleBuiltinBehavior(target, behaviorName) {
			switch (behaviorName) {
				case "wx://component-export": break;
				case "wx://form-field": break;
				case "wx://form-field-button": break;
				default: console.warn(`[service] 未知的内置 behavior: ${behaviorName}`);
			}
		}
		behaviors.forEach((behavior) => merge(obj, behavior));
	}
	/**
	* 检查一个组件是否是指定组件的子组件(包括深层嵌套)
	* ComponentA (__id__: 'a')
	└─ ComponentB (__id__: 'b', __parentId__: 'a')
	└─ ComponentC (__id__: 'c', __parentId__: 'b', class: 'target')
	* @param {object} component 待检查的组件
	* @param {string} parentId 父组件ID
	* @param {Array} allComponents 所有组件列表
	* @returns {boolean} 是否为子组件
	*/
	function isChildComponent(component, parentId, allComponents) {
		let parent = component;
		while (parent && parent.__parentId__) {
			if (parent.__parentId__ === parentId) return true;
			parent = allComponents.find((item) => item.__id__ === parent.__parentId__);
		}
		return false;
	}
	/**
	* 根据选择器匹配组件
	* @param {string} selector 选择器
	* @param {object} item 待匹配的组件
	* @returns {boolean} 是否匹配
	*/
	function matchComponent(selector, item) {
		if (!selector || !item) return false;
		if (selector.startsWith("#")) {
			const id = selector.slice(1);
			return item.id === id;
		}
		if (selector.startsWith(".")) {
			const className = selector.slice(1);
			return item.__targetInfo__?.class && item.__targetInfo__.class.split(" ").includes(className);
		}
		if (selector.startsWith("[") && selector.endsWith("]")) {
			const attrMatch = selector.slice(1, -1).match(/^(\w+)(?:=["']?([^"']*)["']?)?$/);
			if (attrMatch) {
				const [, attrName, attrValue] = attrMatch;
				const dataset = item.__targetInfo__?.dataset || {};
				if (attrValue === void 0) return Object.hasOwn(dataset, attrName);
				return dataset[attrName] === attrValue;
			}
			return false;
		}
		if (item.is) return item.is.split("/").pop() === selector || item.is === selector;
		return false;
	}
	/**
	* 检查表达式的依赖是否发生变化
	* @param {object} bindingInfo 绑定信息对象（包含 expression, dependencies, isSimple）
	* @param {object} changedData 变化的数据
	* @returns {boolean} 是否有依赖变化
	*/
	function hasDependencyChanged(bindingInfo, changedData) {
		if (!bindingInfo || !Array.isArray(bindingInfo.dependencies)) return false;
		for (const dep of bindingInfo.dependencies) {
			if (dep in changedData) return true;
			for (const changedKey of Object.keys(changedData)) {
				if (changedKey.startsWith(dep + ".") || changedKey.startsWith(dep + "[")) return true;
				if (dep.startsWith(changedKey + ".") || dep.startsWith(changedKey + "[")) return true;
			}
		}
		return false;
	}
	/**
	* 计算表达式的新值
	* @param {object} bindingInfo 绑定信息对象（包含 expression, dependencies, isSimple）
	* @param {object} parentData 父组件的完整数据
	* @returns {*} 计算后的值
	*/
	function evaluateExpression(bindingInfo, parentData) {
		if (!bindingInfo || !bindingInfo.expression) return;
		if (bindingInfo.isSimple) return get(parentData, bindingInfo.expression);
		try {
			return new Function("data", `with(data) { return ${bindingInfo.expression} }`)(parentData);
		} catch (error) {
			console.warn("[service] 计算表达式失败:", bindingInfo.expression, error);
			return;
		}
	}
	/**
	* 同步更新子组件的 properties
	* 在父组件/页面 setData 时，同步更新所有受影响的子组件，确保 selectComponent 能立即获取到最新值
	* 完全依赖编译器提供的绑定关系，支持复杂表达式
	* @param {object} parent 父组件或页面实例
	* @param {object} allInstances 所有组件实例对象（来自 runtime.instances[bridgeId]）
	* @param {object} changedData 父组件变化的数据（新值）
	*/
	function syncUpdateChildrenProps(parent, allInstances, changedData) {
		const children = Object.values(allInstances || {});
		const syncedChildren = [];
		for (const child of children) {
			if (!isChildComponent(child, parent.__id__, children) || child.__parentId__ !== parent.__id__) continue;
			const childProperties = child.__info__?.properties || {};
			const updateData = {};
			for (const propName in childProperties) {
				const bindingInfo = parent.__childPropsBindings__?.[child.__id__]?.[propName];
				if (!bindingInfo) continue;
				if (hasDependencyChanged(bindingInfo, changedData)) updateData[propName] = evaluateExpression(bindingInfo, parent.data);
			}
			if (Object.keys(updateData).length > 0) {
				child.tO?.(updateData);
				child.__pendingSyncedProps__ = child.__pendingSyncedProps__ || {};
				Object.assign(child.__pendingSyncedProps__, updateData);
				syncedChildren.push({
					child,
					data: updateData
				});
			}
		}
		return syncedChildren;
	}
	//#endregion
	//#region src/instance/component/component.js
	var componentLifetimes = [
		"created",
		"attached",
		"ready",
		"moved",
		"detached",
		"error"
	];
	var pageLifetimes = [
		"show",
		"hide",
		"resize",
		"routeDone"
	];
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html
	*/
	var Component = class {
		constructor(module, opts) {
			this.initd = false;
			this.opts = opts;
			if (opts.targetInfo) {
				this.id = opts.targetInfo.id;
				this.dataset = opts.targetInfo.dataset;
				this.__targetInfo__ = opts.targetInfo;
			}
			this.is = opts.path;
			this.route = opts.path;
			this.query = opts.query;
			this.renderer = "webview";
			this.bridgeId = opts.bridgeId;
			if (!this.id) this.id = opts.bridgeId;
			this.behaviors = module.behaviors;
			this.data = cloneDeep(module.noReferenceData);
			Object.defineProperty(this, "properties", {
				get() {
					return this.data;
				},
				enumerable: true,
				configurable: false
			});
			this.__isComponent__ = module.isComponent;
			this.__type__ = module.type;
			this.__id__ = this.opts.moduleId;
			this.__info__ = module.moduleInfo;
			this.__eventAttr__ = opts.eventAttr;
			this.__pageId__ = opts.pageId;
			this.__parentId__ = opts.parentId;
			this.__relations__ = /* @__PURE__ */ new Map();
			this.__relationPaths__ = /* @__PURE__ */ new Map();
			this.__groupSetDataMode__ = false;
			this.__groupSetDataBuffer__ = {};
			this.__groupSetDataCallbacks__ = [];
			this.__pendingInitSetDataCallbacks__ = [];
			this.__childPropsBindings__ = {};
			this.__pendingSyncedProps__ = {};
			this.__initialPropertyObserversInvoked__ = false;
		}
		init() {
			if (this.__isComponent__) for (const key in this.__info__.properties) if (!Object.hasOwn(this.opts.properties, key) || this.opts.properties[key] === void 0) this.data[key] = this.__info__.properties[key]?.value ?? null;
			else this.data[key] = this.opts.properties[key];
			this.#initLifecycle();
			this.#initCustomMethods();
			this.#initRelations();
			this.#initComponentExport();
			return this.#invokeInitLifecycle().then(() => {
				addComputedData(this);
				message_default.send({
					type: this.__id__,
					target: "render",
					body: {
						bridgeId: this.bridgeId,
						path: this.is,
						data: this.data
					}
				});
			});
		}
		flushInitSetDataCallbacks() {
			if (this.__pendingInitSetDataCallbacks__.length === 0) return;
			const callbacks = this.__pendingInitSetDataCallbacks__;
			this.__pendingInitSetDataCallbacks__ = [];
			enqueueUpdate(this.bridgeId, this.__id__, {}, createUpdateCallback(this, callbacks));
		}
		/**
		* 初始化组件导出功能
		* 处理 wx://component-export behavior
		*/
		#initComponentExport() {
			if (this.hasBehavior("wx://component-export")) {
				if (this.__info__.export && isFunction(this.__info__.export)) this.export = this.__info__.export.bind(this);
			}
		}
		/**
		* 初始化组件间关系
		*/
		#initRelations() {
			const relations = this.__info__.relations;
			if (!relations || typeof relations !== "object") return;
			for (const [relationPath] of Object.entries(relations)) {
				const resolvedPath = this.#resolveRelationPath(relationPath);
				this.__relationPaths__.set(relationPath, resolvedPath);
				if (!this.__relations__.has(relationPath)) this.__relations__.set(relationPath, []);
			}
		}
		/**
		* 解析关系路径，将相对路径转换为绝对路径
		*/
		#resolveRelationPath(relationPath) {
			if (relationPath.startsWith("./")) {
				const lastSlashIndex = this.is.lastIndexOf("/");
				if (lastSlashIndex === -1) return relationPath.substring(2);
				return `${this.is.substring(0, lastSlashIndex)}/${relationPath.substring(2)}`;
			} else if (relationPath.startsWith("../")) {
				const pathParts = this.is.split("/");
				const relationParts = relationPath.split("/");
				let currentParts = pathParts.slice(0, -1);
				for (const part of relationParts) if (part === "..") currentParts.pop();
				else if (part !== ".") currentParts.push(part);
				return currentParts.join("/");
			} else return relationPath;
		}
		/**
		* 检查组件关系并建立连接
		*/
		#checkAndLinkRelations() {
			const relations = this.__info__.relations;
			if (!relations) return;
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {});
			for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const { type, target } = relationConfig;
				const resolvedPath = this.__relationPaths__.get(relationPath);
				const relatedComponents = allInstances.filter((instance) => {
					if (target) return instance.hasBehavior && instance.hasBehavior(target);
					else return instance.is === resolvedPath || instance.is.endsWith(`/${resolvedPath}`);
				}).filter((instance) => {
					return this.#checkRelationType(instance, type) || this.#checkImplicitRelation(instance, type);
				});
				for (const relatedComponent of relatedComponents) this.#linkRelation(relationPath, relatedComponent, relationConfig);
			}
			this.#notifyOthersToCheckRelations();
		}
		/**
		* 通知其他组件重新检查关系
		*/
		#notifyOthersToCheckRelations() {
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {});
			for (const instance of allInstances) if (instance !== this && instance._checkRelationsWithTarget) instance._checkRelationsWithTarget(this);
		}
		/**
		* 检查与特定目标组件的关系
		*/
		_checkRelationsWithTarget(targetInstance) {
			const relations = this.__info__.relations;
			if (!relations) return;
			for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const { type, target } = relationConfig;
				const resolvedPath = this.__relationPaths__.get(relationPath);
				let matches = false;
				if (target) matches = targetInstance.hasBehavior && targetInstance.hasBehavior(target);
				else matches = targetInstance.is === resolvedPath || targetInstance.is.endsWith(`/${resolvedPath}`);
				const direct = this.#checkRelationType(targetInstance, type);
				const implicit = this.#checkImplicitRelation(targetInstance, type);
				if (matches && (direct || implicit)) this.#linkRelation(relationPath, targetInstance, relationConfig);
			}
		}
		#checkImplicitRelation(targetInstance, relationType) {
			if (relationType !== "descendant" && relationType !== "ancestor") return false;
			const reverseRelationType = relationType === "descendant" ? "ancestor" : "descendant";
			const targetRelations = targetInstance.__info__?.relations;
			if (!targetRelations) return false;
			return Object.entries(targetRelations).some(([relationPath, relationConfig]) => {
				const resolvedPath = targetInstance.__relationPaths__?.get(relationPath);
				return relationConfig.type === reverseRelationType && (this.is === resolvedPath || this.is.endsWith(`/${resolvedPath}`));
			});
		}
		/**
		* 检查关系类型是否匹配
		*/
		#checkRelationType(targetInstance, relationType) {
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {});
			switch (relationType) {
				case "parent": return targetInstance.__id__ === this.__parentId__;
				case "child": return targetInstance.__parentId__ === this.__id__;
				case "ancestor": return this.#isAncestor(targetInstance.__id__, this.__id__, allInstances);
				case "descendant": return this.#isAncestor(this.__id__, targetInstance.__id__, allInstances);
				default: return false;
			}
		}
		/**
		* 检查 ancestorId 是否是 descendantId 的祖先
		*/
		#isAncestor(ancestorId, descendantId, allInstances) {
			let current = allInstances.find((instance) => instance.__id__ === descendantId);
			while (current && current.__parentId__) {
				if (current.__parentId__ === ancestorId) return true;
				current = allInstances.find((instance) => instance.__id__ === current.__parentId__);
			}
			return false;
		}
		/**
		* 建立关系连接
		*/
		#linkRelation(relationPath, targetInstance, relationConfig) {
			const relationNodes = this.__relations__.get(relationPath) || [];
			if (relationNodes.includes(targetInstance)) return;
			relationNodes.push(targetInstance);
			this.__relations__.set(relationPath, relationNodes);
			if (isFunction(relationConfig.linked)) try {
				relationConfig.linked.call(this, targetInstance);
			} catch (error) {
				console.error("[service] relation linked error:", error);
			}
		}
		/**
		* 移除关系连接
		*/
		#unlinkRelation(relationPath, targetInstance, relationConfig) {
			const relationNodes = this.__relations__.get(relationPath) || [];
			const index = relationNodes.indexOf(targetInstance);
			if (index === -1) return;
			relationNodes.splice(index, 1);
			this.__relations__.set(relationPath, relationNodes);
			if (isFunction(relationConfig.unlinked)) try {
				relationConfig.unlinked.call(this, targetInstance);
			} catch (error) {
				console.error("[service] relation unlinked error:", error);
			}
		}
		/**
		* 处理关系变化
		*/
		#handleRelationChange(relationPath, targetInstance, relationConfig) {
			if (isFunction(relationConfig.linkChanged)) try {
				relationConfig.linkChanged.call(this, targetInstance);
			} catch (error) {
				console.error("[service] relation linkChanged error:", error);
			}
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/performance/tips/runtime_setData.html
		* @param {*} data
		*/
		setData(data, callback) {
			const fData = filterData(data);
			const oldValues = {};
			for (const key in fData) {
				oldValues[key] = this.data[key];
				set(this.data, key, fData[key]);
			}
			if (this.__info__.observers) invokeObserversOnce(Object.keys(fData), this.__info__.observers, this.data, this, oldValues);
			invokeBehaviorObservers(this, Object.keys(fData), oldValues);
			invokePropertyObservers(this, Object.keys(fData), oldValues);
			if (!this.initd) {
				if (isFunction(callback)) this.__pendingInitSetDataCallbacks__.push(callback);
				return;
			}
			if (this.__groupSetDataMode__) {
				for (const key in fData) this.__groupSetDataBuffer__[key] = fData[key];
				if (isFunction(callback)) this.__groupSetDataCallbacks__.push(callback);
				return;
			}
			const syncedChildren = syncUpdateChildrenProps(this, runtime_default.instances[this.bridgeId], fData);
			enqueueUpdate(this.bridgeId, this.__id__, fData, createUpdateCallback(this, callback));
			syncedChildren.forEach(({ child, data }) => {
				enqueueUpdate(this.bridgeId, child.__id__, data);
			});
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
		*/
		#initLifecycle() {
			componentLifetimes.forEach((method) => {
				const lifecycleMethod = this.__info__.lifetimes?.[method] || this.__info__[method];
				if (!isFunction(lifecycleMethod)) return;
				this[method] = lifecycleMethod.bind(this);
			});
			if (this.__isComponent__) pageLifetimes.forEach((method) => {
				const lifecycleMethod = this.__info__.pageLifetimes?.[method];
				if (!isFunction(lifecycleMethod)) return;
				if (method === "show") method = "onShow";
				else if (method === "hide") method = "onHide";
				this[method] = lifecycleMethod.bind(this);
			});
		}
		/**
		* 开发者自定义函数
		* Component 构造器的主要区别是：方法需要放在 methods: { } 里面
		*/
		#initCustomMethods() {
			const methods = this.__info__.methods;
			for (const attr in methods) if (isFunction(methods[attr])) this[attr] = methods[attr].bind(this);
		}
		#invokeInitialPropertyObservers() {
			if (!this.__isComponent__ || !this.__info__.properties || this.__initialPropertyObserversInvoked__) return;
			const propertyObserversToExecute = [];
			for (const prop of Object.keys(this.__info__.properties)) {
				const observer = this.__info__.properties[prop]?.observer;
				const val = this.data[prop];
				if (isString(observer)) propertyObserversToExecute.push(() => this[observer]?.(val, void 0));
				else if (isFunction(observer)) propertyObserversToExecute.push(() => observer.call(this, val, void 0));
			}
			propertyObserversToExecute.forEach((run) => run());
			this.__initialPropertyObserversInvoked__ = true;
		}
		async #invokeInitLifecycle() {
			if (this.__isComponent__) {
				await this.componentCreated();
				await this.componentAttached();
			} else {
				await this.componentCreated();
				await this.componentAttached();
				await this.onLoad?.(this.opts.query || {});
			}
			this.initd = true;
		}
		/**
		* 触发观察者函数
		* triggerObserver
		*/
		tO(data) {
			const nextData = {};
			for (const [prop, val] of Object.entries(data)) {
				if (this.__pendingSyncedProps__ && Object.hasOwn(this.__pendingSyncedProps__, prop) && deepEqual(this.__pendingSyncedProps__[prop], val)) {
					this.data[prop] = val;
					delete this.__pendingSyncedProps__[prop];
					continue;
				}
				nextData[prop] = val;
			}
			if (Object.keys(nextData).length === 0) return;
			const observersToExecute = [];
			const oldValues = {};
			for (const [prop, val] of Object.entries(nextData)) {
				const oldVal = this.data[prop];
				oldValues[prop] = oldVal;
				this.data[prop] = val;
				if (this.__info__.observers) observersToExecute.push(() => filterInvokeObserver(prop, this.__info__.observers, this.data, this, oldVal));
			}
			observersToExecute.forEach((run) => run());
			invokeBehaviorObservers(this, Object.keys(nextData), Object.fromEntries(Object.keys(nextData).map((prop) => [prop, void 0])));
			runPropertyObservers(this, Object.keys(nextData), oldValues);
		}
		getPageId() {
			return this.__id__;
		}
		/**
		* 检查组件是否具有 behavior （检查时会递归检查被直接或间接引入的所有behavior）
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/behaviors.html
		*/
		hasBehavior(behavior) {
			const _hasBehavior = function(behaviors) {
				if (!Array.isArray(behaviors)) return false;
				if (behaviors.includes(behavior)) return true;
				for (const b of behaviors) if (b && b.behaviors && _hasBehavior(b.behaviors)) return true;
				return false;
			};
			return _hasBehavior(this.behaviors);
		}
		/**
		* 创建一个 SelectorQuery 对象，选择器选取范围为这个组件实例内
		*/
		createSelectorQuery() {
			return createSelectorQuery().in(this);
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html#获取组件实例
		* 使用选择器选取子组件实例对象，返回匹配到的第一个组件实例对象
		*/
		selectComponent(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId]);
			const matchedComponent = children.find((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item));
			if (!matchedComponent) return null;
			if (matchedComponent.hasBehavior("wx://component-export") && matchedComponent.export) return matchedComponent.export();
			return matchedComponent;
		}
		/**
		* 使用选择器选取子组件实例对象，返回匹配到的全部组件实例对象组成的数组
		*/
		selectAllComponents(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId]);
			return children.filter((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item));
		}
		/**
		* 选取当前组件节点所在的组件实例（即组件的引用者），返回它的组件实例对象
		*/
		selectOwnerComponent() {
			const children = Object.values(runtime_default.instances[this.bridgeId]);
			for (const item of children) if (item.id === this.__parentId__) return item;
			return null;
		}
		/**
		* 创建一个 IntersectionObserver 对象，选择器选取范围为这个组件实例内
		* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html#createIntersectionObserver-Object-options
		*/
		createIntersectionObserver(options) {
			return createIntersectionObserver(this, options);
		}
		/**
		* 立刻执行 callback，其中的多个 setData 之间不会触发界面绘制
		* （只有某些特殊场景中需要，如用于在不同组件同时 setData 时进行界面绘制同步）
		* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html#groupSetData-Function-callback
		* @param {Function} callback 回调函数，在此函数中进行的多个 setData 调用会被合并
		*/
		groupSetData(callback) {
			if (!isFunction(callback)) {
				console.warn("[service] groupSetData callback must be a function");
				return;
			}
			this.__groupSetDataMode__ = true;
			beginUpdateBatch(this.bridgeId);
			this.__groupSetDataBuffer__ = {};
			this.__groupSetDataCallbacks__ = [];
			try {
				callback.call(this);
			} catch (error) {
				console.error("[service] groupSetData callback error:", error);
			} finally {
				this.__groupSetDataMode__ = false;
				if (this.__groupSetDataBuffer__ && Object.keys(this.__groupSetDataBuffer__).length > 0) {
					const bufferedData = this.__groupSetDataBuffer__;
					const bufferedCallbacks = this.__groupSetDataCallbacks__;
					this.__groupSetDataBuffer__ = {};
					this.__groupSetDataCallbacks__ = [];
					const syncedChildren = syncUpdateChildrenProps(this, runtime_default.instances[this.bridgeId], bufferedData);
					enqueueUpdate(this.bridgeId, this.__id__, bufferedData, createUpdateCallback(this, bufferedCallbacks));
					syncedChildren.forEach(({ child, data }) => {
						enqueueUpdate(this.bridgeId, child.__id__, data);
					});
				} else {
					this.__groupSetDataBuffer__ = {};
					this.__groupSetDataCallbacks__ = [];
				}
				endUpdateBatch(this.bridgeId);
			}
		}
		/**
		* TODO: 创建一个 MediaQueryObserver 对象
		*/
		createMediaQueryObserver() {
			console.warn("[service] 暂不支持 createMediaQueryObserver");
		}
		/**
		* 获取这个关系所对应的所有关联节点
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/relations.html
		*/
		getRelationNodes(relationPath) {
			if (!relationPath) {
				console.warn("[service] getRelationNodes 需要传入关系路径参数");
				return [];
			}
			return [...this.__relations__.get(relationPath) || []];
		}
		/**
		* TODO: 执行关键帧动画
		*/
		animate() {
			console.warn("[service] 暂不支持 animate");
		}
		/**
		* TODO: 清除关键帧动画
		*/
		clearAnimation() {
			console.warn("[service] 暂不支持 clearAnimation");
		}
		/**
		* 触发组件所在页面的事件逻辑
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html
		* @param {*} methodName
		* @param {*} detail // detail对象，提供给事件监听函数
		* @param {*} options // 触发事件的选项
		*/
		async triggerEvent(methodName, detail, options = {}) {
			if (!methodName) return;
			const type = methodName.trim();
			const eventHandler = resolveEventHandler(this.__eventAttr__, type);
			if (eventHandler) await runtime_default.triggerEvent({
				bridgeId: this.bridgeId,
				moduleId: this.__pageId__,
				methodName: eventHandler,
				event: {
					type,
					detail,
					currentTarget: {
						id: this.id,
						dataset: this.dataset
					},
					target: {
						id: this.id,
						dataset: this.dataset
					}
				}
			});
			if (options.bubbles) await runtime_default.instances[this.bridgeId][this.__parentId__]?.triggerEvent(methodName, detail);
			if (options.composed) {}
			if (options.capturePhase) {}
		}
		pageReady() {
			if (!this.__isComponent__) this.ready?.();
		}
		/**
		* 页面退出时执行
		*/
		pageUnload() {
			if (!this.__isComponent__) this.onUnload?.();
		}
		pageScrollTop(opts) {
			if (!this.__isComponent__) {
				const { scrollTop } = opts;
				this.onPageScroll?.({ scrollTop });
			}
		}
		/**
		* 组件所在的页面被展示时执行
		*/
		pageShow() {
			this.__info__.behaviorPageLifetimes?.show?.forEach((method) => method.call(this));
			this.onShow?.();
		}
		/**
		* 组件所在的页面被隐藏时执行
		*/
		pageHide() {
			this.__info__.behaviorPageLifetimes?.hide?.forEach((method) => method.call(this));
			this.onHide?.();
		}
		/**
		* 组件所在的页面尺寸变化时执行
		* @param {object} size
		*/
		pageResize(size) {
			this.__info__.behaviorPageLifetimes?.resize?.forEach((method) => method.call(this, size));
			this.resize?.(size);
		}
		componentRouteDone() {
			this.__info__.behaviorPageLifetimes?.routeDone?.forEach((method) => method.call(this));
			this.routeDone?.();
		}
		/**
		* 在组件实例刚刚被创建时执行
		*/
		async componentCreated() {
			this.__info__.behaviorLifetimes?.created?.forEach((method) => method.call(this));
			await this.created?.();
		}
		/**
		* 在组件实例进入页面节点树时执行
		*/
		async componentAttached() {
			this.__info__.behaviorLifetimes?.attached?.forEach((method) => method.call(this));
			await this.attached?.();
			this.#checkAndLinkRelations();
		}
		/**
		* 在组件在视图层布局完成后执行
		*/
		componentReadied() {
			this.#invokeInitialPropertyObservers();
			this.__info__.behaviorLifetimes?.ready?.forEach((method) => method.call(this));
			this.ready?.();
		}
		/**
		* 在组件实例被移动到节点树另一个位置时执行
		*/
		componentMoved() {
			this.moved?.();
			const relations = this.__info__.relations;
			if (relations) for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const relationNodes = this.__relations__.get(relationPath) || [];
				for (const node of relationNodes) this.#handleRelationChange(relationPath, node, relationConfig);
			}
		}
		/**
		* 在组件实例被从页面节点树移除时执行
		*/
		componentDetached() {
			const relations = this.__info__.relations;
			if (relations) for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const nodesToUnlink = [...this.__relations__.get(relationPath) || []];
				for (const node of nodesToUnlink) this.#unlinkRelation(relationPath, node, relationConfig);
			}
			this.#notifyOthersToUnlinkThis();
			this.__info__.behaviorLifetimes?.detached?.forEach((method) => method.call(this));
			this.detached?.();
			this.initd = false;
		}
		/**
		* 通知其他组件移除对当前组件的引用
		*/
		#notifyOthersToUnlinkThis() {
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {});
			for (const instance of allInstances) {
				if (instance === this || !instance.__relations__) continue;
				for (const [relationPath, relationNodes] of instance.__relations__.entries()) {
					const index = relationNodes.indexOf(this);
					if (index !== -1) {
						relationNodes.splice(index, 1);
						instance.__relations__.set(relationPath, relationNodes);
						const relationConfig = instance.__info__.relations?.[relationPath];
						if (relationConfig && isFunction(relationConfig.unlinked)) try {
							relationConfig.unlinked.call(instance, this);
						} catch (error) {
							console.error("[service] relation unlinked error:", error);
						}
					}
				}
			}
		}
		/**
		* 每当组件方法抛出错误时执行
		* @param {*} error
		*/
		componentError(error) {
			this.error?.(error);
		}
	};
	//#endregion
	//#region src/instance/component/component-module.js
	var ComponentModule = class ComponentModule {
		static type = "component";
		/**
		*
		* @param {{data: object, lifetimes: object, pageLifetimes: object, methods: object, options: object, properties: object}} moduleInfo
		*/
		constructor(moduleInfo, extraInfo) {
			this.moduleInfo = moduleInfo;
			this.extraInfo = extraInfo;
			this.type = ComponentModule.type;
			this.isComponent = this.extraInfo.component;
			this.behaviors = this.moduleInfo.behaviors;
			this.usingComponents = this.extraInfo.usingComponents;
			mergeBehaviors(this.moduleInfo, this.behaviors);
			this.noReferenceData = filterData(this.moduleInfo.data || {});
		}
		getProps() {
			let props = serializeProps(this.moduleInfo.properties);
			if (Array.isArray(this.moduleInfo.externalClasses) && this.moduleInfo.externalClasses.length > 0) {
				if (!props) props = {};
				for (const externalClass of this.moduleInfo.externalClasses) props[externalClass] = {
					type: ["s"],
					cls: true
				};
			}
			return props;
		}
	};
	//#endregion
	//#region src/instance/page/page.js
	var Page = class {
		constructor(module, opts) {
			this.initd = false;
			this.opts = opts;
			this.is = opts.path;
			this.route = opts.path;
			this.bridgeId = opts.bridgeId;
			this.id = opts.bridgeId;
			this.query = opts.query;
			this.data = cloneDeep(module.noReferenceData);
			this.__type__ = module.type;
			this.__id__ = opts.moduleId;
			this.__info__ = module.moduleInfo;
			this.__childPropsBindings__ = {};
			this.__pendingInitSetDataCallbacks__ = [];
		}
		init() {
			this.#initMembers();
			return this.#invokeInitLifecycle().then(() => {
				addComputedData(this);
				message_default.send({
					type: this.__id__,
					target: "render",
					body: {
						bridgeId: this.bridgeId,
						path: this.is,
						data: this.data
					}
				});
			});
		}
		flushInitSetDataCallbacks() {
			if (this.__pendingInitSetDataCallbacks__.length === 0) return;
			const callbacks = this.__pendingInitSetDataCallbacks__;
			this.__pendingInitSetDataCallbacks__ = [];
			enqueueUpdate(this.bridgeId, this.__id__, {}, createUpdateCallback(this, callbacks));
		}
		setData(data, callback) {
			const fData = filterData(data);
			const oldValues = {};
			const info = this.__info__ || {};
			for (const key in fData) {
				oldValues[key] = this.data[key];
				set(this.data, key, fData[key]);
			}
			if (info.observers) invokeObserversOnce(Object.keys(fData), info.observers, this.data, this, oldValues);
			invokeBehaviorObservers(this, Object.keys(fData), oldValues);
			if (!this.initd) {
				if (isFunction(callback)) this.__pendingInitSetDataCallbacks__.push(callback);
				return;
			}
			const syncedChildren = syncUpdateChildrenProps(this, runtime_default.instances[this.bridgeId], fData);
			enqueueUpdate(this.bridgeId, this.__id__, fData, createUpdateCallback(this, callback));
			syncedChildren.forEach(({ child, data }) => {
				enqueueUpdate(this.bridgeId, child.__id__, data);
			});
		}
		/**
		* 创建一个 SelectorQuery 对象，选择器选取范围为这个页面实例内
		*/
		createSelectorQuery() {
			return createSelectorQuery().in(this);
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html#获取组件实例
		* 使用选择器选取页面中的组件实例对象，返回匹配到的第一个组件实例对象
		*/
		selectComponent(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId] || {});
			const matchedComponent = children.find((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item));
			if (!matchedComponent) return null;
			if (matchedComponent.hasBehavior && matchedComponent.hasBehavior("wx://component-export") && matchedComponent.export) return matchedComponent.export();
			return matchedComponent;
		}
		/**
		* 使用选择器选取页面中的组件实例对象，返回匹配到的全部组件实例对象组成的数组
		*/
		selectAllComponents(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId] || {});
			return children.filter((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)).map((component) => {
				if (component.hasBehavior && component.hasBehavior("wx://component-export") && component.export) return component.export();
				return component;
			});
		}
		#initMembers() {
			for (const attr in this.__info__) {
				const member = this.__info__[attr];
				if (isFunction(member)) this[attr] = member.bind(this);
				else this[attr] = member;
			}
		}
		async #invokeInitLifecycle() {
			this.__info__.behaviorLifetimes?.created?.forEach((method) => method.call(this));
			await this.created?.();
			this.__info__.behaviorLifetimes?.attached?.forEach((method) => method.call(this));
			await this.attached?.();
			await this.onLoad?.(this.opts.query || {});
			this.initd = true;
		}
		/**
		* 页面显示/切入前台时触发。该时机不能保证页面渲染完成，如有页面/组件元素相关操作建议在 onReady 中处理
		*/
		pageShow() {
			this.__info__.behaviorPageLifetimes?.show?.forEach((method) => method.call(this));
			this.onShow?.();
		}
		pageHide() {
			this.__info__.behaviorPageLifetimes?.hide?.forEach((method) => method.call(this));
			this.onHide?.();
		}
		pageReady() {
			this.__info__.behaviorLifetimes?.ready?.forEach((method) => method.call(this));
			this.ready?.();
			this.onReady?.();
		}
		pageUnload() {
			this.__info__.behaviorLifetimes?.detached?.forEach((method) => method.call(this));
			this.detached?.();
			this.onUnload?.();
			this.initd = false;
		}
		pageScrollTop(opts) {
			const { scrollTop } = opts;
			this.onPageScroll?.({ scrollTop });
		}
		pageResize(size) {
			this.__info__.behaviorPageLifetimes?.resize?.forEach((method) => method.call(this, size));
			this.onResize?.(size);
		}
	};
	//#endregion
	//#region src/instance/page/page-module.js
	var PageModule = class PageModule {
		static type = "page";
		constructor(moduleInfo, extraInfo) {
			this.moduleInfo = moduleInfo;
			this.extraInfo = extraInfo;
			this.type = PageModule.type;
			this.behaviors = this.moduleInfo.behaviors;
			this.usingComponents = this.extraInfo.usingComponents;
			mergeBehaviors(this.moduleInfo, this.behaviors);
			if (this.moduleInfo.methods) {
				for (const [name, method] of Object.entries(this.moduleInfo.methods)) if (!(name in this.moduleInfo) && isFunction(method)) this.moduleInfo[name] = method;
			}
			this.noReferenceData = filterData(this.moduleInfo.data || {});
		}
	};
	//#endregion
	//#region src/instance/app/app-module.js
	var AppModule = class {
		static type = "app";
		constructor(moduleInfo) {
			this.moduleInfo = moduleInfo;
		}
	};
	//#endregion
	//#region src/core/loader.js
	var Loader = class {
		constructor() {
			this.staticModules = {};
		}
		/**
		* [Container] loadResource -> [Service] loadResource
		* @param {*} opts
		*/
		loadResource(opts) {
			const { appId, bridgeId, pagePath, root, baseUrl } = opts;
			if (isWebWorker) {
				this.isScriptLoaded = this.isScriptLoaded || {};
				if (!this.isScriptLoaded[root]) {
					const logicResourcePath = `${baseUrl}${appId}/${root}/logic.js`;
					globalThis.importScripts(logicResourcePath);
					this.isScriptLoaded[root] = true;
				}
			}
			router_default.setInitId(bridgeId);
			modRequire("app");
			modRequire(pagePath);
			message_default.invoke({
				type: "serviceResourceLoaded",
				target: "service",
				body: { bridgeId }
			});
		}
		/**
		* 创建逻辑层 App 映射实例
		* @param {*} moduleInfo
		*/
		createAppModule(moduleInfo) {
			const appModule = new AppModule(moduleInfo);
			this.staticModules[AppModule.type] = appModule;
		}
		/**
		*创建逻辑层 Page/Component 映射实例
		* [Container]loadResource -> [Service]loadResource -> globalThis.Page/globalThis.Component -> create
		* @param {*} moduleInfo {{data: object, method: object}} 模块逻辑信息
		* @param {*} extraInfo {{path: string, component: boolean, usingComponents: object}} 模块额外信息
		* @param {*} type {{type: string}} type
		*/
		createModule(moduleInfo, extraInfo, type) {
			const { path, usingComponents } = extraInfo;
			if (this.staticModules[path]) return;
			if (usingComponents) for (const componentPath of Object.values(usingComponents)) modRequire(componentPath);
			if (type === PageModule.type) {
				const pageModule = new PageModule(moduleInfo, extraInfo);
				this.staticModules[path] = pageModule;
			} else if (type === ComponentModule.type) {
				const componentModule = new ComponentModule(moduleInfo, extraInfo);
				this.staticModules[path] = componentModule;
			} else console.error(`[service] createModule ${type} error`);
		}
		getPropsByPath(usingComponents) {
			const res = {};
			this.getComponentProps(res, usingComponents);
			return res;
		}
		getComponentProps(res, usingComponents) {
			if (!usingComponents) return;
			for (const componentPath of Object.values(usingComponents)) {
				const component = this.staticModules[componentPath];
				if (!component || res[componentPath]) continue;
				res[componentPath] = component.getProps();
				this.getComponentProps(res, component.usingComponents);
			}
		}
		getAppModule() {
			return this.staticModules[AppModule.type];
		}
		getModuleByPath(path) {
			return this.staticModules[path];
		}
	};
	var loader_default = new Loader();
	//#endregion
	//#region src/core/runtime.js
	var Runtime = class {
		constructor() {
			this.app = null;
			this.instances = {};
		}
		queuePendingEvent(instance, payload) {
			instance.__pendingRuntimeEvents__ = instance.__pendingRuntimeEvents__ || [];
			return new Promise((resolve, reject) => {
				instance.__pendingRuntimeEvents__.push({
					...payload,
					resolve,
					reject
				});
			});
		}
		async flushPendingEvents(instance) {
			const pendingEvents = instance?.__pendingRuntimeEvents__ || [];
			instance.__pendingRuntimeEvents__ = [];
			for (const pendingEvent of pendingEvents) try {
				const result = await this.dispatchEvent(pendingEvent);
				pendingEvent.resolve(result);
			} catch (error) {
				pendingEvent.reject(error);
			}
		}
		async dispatchEvent({ instance, bridgeId, moduleId, methodName, event }) {
			if (isFunction(instance[methodName])) return await instance[methodName](event);
			console.warn(`[service] triggerEvent ${bridgeId} ${moduleId}, is: ${instance.is}, method: ${methodName} is not exist`);
		}
		createApp(opts) {
			if (this.app) {
				console.log("[service] app instance already existed");
				return;
			}
			const { scene, pagePath: path, query } = opts;
			const appModule = loader_default.getAppModule();
			if (!appModule) {
				console.log("[service] app instance is not exist");
				return;
			}
			console.log("[service] create app instance");
			this.app = new App(appModule, {
				scene,
				path,
				query
			});
		}
		appShow() {
			this.app?.appShow();
		}
		appHide() {
			this.app?.appHide();
		}
		stackShow(stackId) {
			router_default.pushStack(stackId);
		}
		stackHide(stackId) {
			router_default.popStack(stackId);
		}
		/**
		* 渲染层创建映射实例
		* [Render]componentCreated -> [Container]createInstance ->[Service]createInstance
		* @param {*} opts
		*/
		createInstance(opts) {
			const { bridgeId, moduleId, path, query, eventAttr, pageId, parentId, properties, targetInfo, stackId } = opts;
			const module = loader_default.getModuleByPath(path);
			if (!module) {
				console.error(`[service] ${path} not exist`);
				return;
			}
			console.log(`[service] create instance ${path}`);
			this.instances[bridgeId] = this.instances[bridgeId] || {};
			if (module.type === ComponentModule.type) {
				const component = new Component(module, {
					bridgeId,
					moduleId,
					path,
					query,
					eventAttr,
					pageId,
					parentId,
					properties,
					targetInfo
				});
				this.instances[bridgeId][moduleId] = component;
				if (!module.isComponent) router_default.push(component, stackId);
				component.init();
				return component;
			} else if (module.type === PageModule.type) {
				const page = new Page(module, {
					bridgeId,
					moduleId,
					path,
					query
				});
				this.instances[bridgeId][moduleId] = page;
				router_default.push(page, stackId);
				page.init();
				return page;
			} else console.error(`[service] ${module.type} instance is not exist.`);
		}
		moduleReady(opts) {
			const { bridgeId, moduleId, propBindings } = opts;
			const instance = this.instances[bridgeId][moduleId];
			if (!instance) return;
			if (propBindings && instance.__parentId__) {
				const parent = this.instances[bridgeId]?.[instance.__parentId__];
				if (parent) {
					if (!parent.__childPropsBindings__) parent.__childPropsBindings__ = {};
					parent.__childPropsBindings__[moduleId] = propBindings;
				}
			}
			if (instance.__type__ === ComponentModule.type) {
				instance.componentReadied();
				instance.__componentReadied__ = true;
				this.flushPendingEvents(instance);
				instance.flushInitSetDataCallbacks?.();
				const pageInstance = this.getPageInstance(bridgeId);
				if (pageInstance) this.checkAndCallPageReady(bridgeId, pageInstance.__id__);
			}
		}
		moduleUnmounted(opts) {
			const { bridgeId, moduleId } = opts;
			const instance = this.instances[bridgeId][moduleId];
			if (!instance) return;
			if (instance.__type__ === ComponentModule.type) instance.componentDetached();
			delete this.instances[bridgeId][moduleId];
		}
		pageShow(opts) {
			const { bridgeId } = opts;
			const instances = this.instances[bridgeId];
			if (!instances) return;
			const pageInstances = [];
			Object.values(instances).forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === PageModule.type) pageInstances.push(instance);
				else if (instance.__type__ === ComponentModule.type) if (!instance.__isComponent__) pageInstances.push(instance);
				else instance.pageShow();
			});
			pageInstances.forEach((instance) => {
				instance.pageShow();
			});
		}
		pageReady(opts) {
			const { bridgeId, moduleId } = opts;
			const instance = this.instances[bridgeId][moduleId];
			if (!instance) return;
			this.pageShow(opts);
			instance.__pageReadyPending__ = true;
			instance.flushInitSetDataCallbacks?.();
			this.checkAndCallPageReady(bridgeId, moduleId);
		}
		/**
		* 检查并调用页面的 onReady
		* 确保所有组件的 ready 都已执行完毕
		*/
		/**
		* 获取指定 bridgeId 下的页面实例
		*/
		getPageInstance(bridgeId) {
			const instances = this.instances[bridgeId];
			if (!instances) return null;
			return Object.values(instances).find((instance) => {
				return instance && (instance.__type__ === PageModule.type || instance.__type__ === ComponentModule.type && !instance.__isComponent__);
			});
		}
		checkAndCallPageReady(bridgeId, moduleId) {
			const instance = this.instances[bridgeId][moduleId];
			if (!instance || !instance.__pageReadyPending__) return;
			const instances = this.instances[bridgeId];
			if (!instances) {
				instance.__pageReadyPending__ = false;
				instance.pageReady();
				return;
			}
			if (Object.values(instances).filter((componentInstance) => {
				return componentInstance && componentInstance.__type__ === ComponentModule.type && componentInstance.__isComponent__ && componentInstance.initd && !componentInstance.__componentReadied__;
			}).length === 0) {
				instance.__pageReadyPending__ = false;
				instance.pageReady();
			}
		}
		pageHide(opts) {
			const { bridgeId } = opts;
			const instances = this.instances[bridgeId];
			const pageInstances = [];
			Object.values(instances).forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === PageModule.type) pageInstances.push(instance);
				else if (instance.__type__ === ComponentModule.type) if (!instance.__isComponent__) pageInstances.push(instance);
				else instance.pageHide();
			});
			pageInstances.forEach((instance) => {
				if (!instance) return;
				instance.pageHide();
			});
		}
		pageUnload(opts) {
			const { bridgeId } = opts;
			const instances = this.instances[bridgeId];
			if (!instances) return;
			Object.values(instances).forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === ComponentModule.type) instance.componentDetached();
				instance.pageUnload();
			});
			router_default.pop();
			delete this.instances[bridgeId];
		}
		pageScroll(opts) {
			const { bridgeId, moduleId, scrollTop } = opts;
			const instance = this.instances[bridgeId][moduleId];
			if (!instance) return;
			instance.pageScrollTop({ scrollTop });
		}
		pageResize(opts) {
			const { bridgeId, size } = opts;
			const instances = this.instances[bridgeId];
			if (!instances) return;
			Object.values(instances).forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === PageModule.type) instance.pageResize(size);
				else if (instance.__type__ === ComponentModule.type) if (!instance.__isComponent__) instance.pageResize(size);
				else instance.pageResize(size);
			});
		}
		componentError(opts) {
			const { bridgeId, moduleId } = opts;
			const instance = this.instances[bridgeId][moduleId];
			if (!instance) return;
			if (instance.__type__ === ComponentModule.type) instance.componentError();
		}
		componentRouteDone(opts) {
			const { bridgeId } = opts;
			const instances = this.instances[bridgeId];
			if (!instances) return;
			Object.values(instances).forEach((instance) => {
				if (instance?.__type__ === ComponentModule.type) instance.componentRouteDone();
			});
		}
		/**
		* 调用业务 js 方法
		* @param {*} opts
		*/
		async triggerEvent(opts) {
			const { bridgeId, moduleId, methodName, event } = opts;
			if (methodName === void 0) return;
			const instances = this.instances[bridgeId];
			if (!instances) {
				console.warn(`[service] No instances found for bridgeId: ${bridgeId}`);
				return;
			}
			const instance = instances[moduleId];
			if (!instance) {
				console.warn(`[service] triggerEvent ${bridgeId} ${moduleId} ${methodName}, instance is not exist`);
				return;
			}
			if (instance.__type__ === ComponentModule.type && instance.__isComponent__ && !instance.__componentReadied__) return this.queuePendingEvent(instance, {
				instance,
				bridgeId,
				moduleId,
				methodName,
				event
			});
			return this.dispatchEvent({
				instance,
				bridgeId,
				moduleId,
				methodName,
				event
			});
		}
	};
	var runtime_default = new Runtime();
	//#endregion
	//#region src/api/core/life-cycle/index.js
	var life_cycle_exports = /* @__PURE__ */ __exportAll({
		getEnterOptionsSync: () => getEnterOptionsSync,
		getLaunchOptionsSync: () => getLaunchOptionsSync
	});
	/**
	* 获取小程序启动时的参数。与 App.onLaunch 的回调参数一致
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/life-cycle/wx.getLaunchOptionsSync.html
	*/
	function getLaunchOptionsSync() {
		return runtime_default.app?.options;
	}
	/**
	* 获取本次小程序启动时的参数。如果当前是冷启动，则返回值与 App.onLaunch 的回调参数一致；如果当前是热启动，则返回值与 App.onShow 一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/life-cycle/wx.getEnterOptionsSync.html
	*/
	function getEnterOptionsSync() {
		return runtime_default.app?.options;
	}
	//#endregion
	//#region src/api/core/location/index.js
	var location_exports = /* @__PURE__ */ __exportAll({
		getLocation: () => getLocation,
		offLocationChange: () => offLocationChange,
		onLocationChange: () => onLocationChange,
		openLocation: () => openLocation,
		startLocationUpdate: () => startLocationUpdate,
		stopLocationUpdate: () => stopLocationUpdate
	});
	/**
	* 获取当前的地理位置、速度。
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.getLocation.html
	*/
	function getLocation(opts) {
		invokeAPI("getLocation", opts);
	}
	/**
	* 开启小程序进入前台时接收位置消息。
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.startLocationUpdate.html
	*/
	function startLocationUpdate(opts) {
		invokeAPI("startLocationUpdate", opts);
	}
	/**
	* 使用内置地图查看位置
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.openLocation.html
	*/
	function openLocation(opts) {
		invokeAPI("openLocation", opts);
	}
	/**
	* 关闭监听实时位置变化，前后台都停止消息接收
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.stopLocationUpdate.html
	*/
	function stopLocationUpdate(opts) {
		invokeAPI("stopLocationUpdate", opts);
	}
	/**
	* 监听实时地理位置变化事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.onLocationChange.html
	*/
	function onLocationChange(listener) {
		if (listener) invokeAPI("onLocationChange", { success: callback_default.store(listener, true) });
	}
	/**
	* 移除实时地理位置变化事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.offLocationChange.html
	* @param {*} listener onLocationChange 传入的监听函数。不传此参数则移除所有监听函数。
	*/
	function offLocationChange(listener) {
		if (listener) {
			const id = callback_default.store(listener, true);
			invokeAPI("offLocationChange", { success: id });
			callback_default.remove(id);
		} else {
			invokeAPI("offLocationChange");
			callback_default.remove();
		}
	}
	//#endregion
	//#region src/api/core/map/index.js
	var map_exports = /* @__PURE__ */ __exportAll({ createMapContext: () => createMapContext });
	function createMapContext(mapId, obj) {
		return new MapContext({
			mapId,
			obj
		});
	}
	var MapContext = class {
		constructor(opts) {
			this.opts = opts;
		}
		addMarkers(data) {
			invokeAPI("addMarkers", data);
		}
		removeMarkers(data) {
			invokeAPI("removeMarkers", data);
		}
		includePoints(data) {
			invokeAPI("includePoints", data);
		}
		setCenterOffset(data) {
			invokeAPI("setCenterOffset", data);
		}
		getCenterLocation(data) {
			invokeAPI("getCenterLocation", data);
		}
		getScale(data) {
			invokeAPI("getScale", data);
		}
		moveToLocation(data) {
			invokeAPI("moveToLocation", data);
		}
		translateMarker(data) {
			invokeAPI("translateMarker", data);
		}
		addArc(data) {
			invokeAPI("addArc", data);
		}
		removeArc(data) {
			invokeAPI("removeArc", data);
		}
	};
	//#endregion
	//#region src/api/core/media/image/index.js
	var image_exports = /* @__PURE__ */ __exportAll({
		chooseImage: () => chooseImage,
		compressImage: () => compressImage,
		previewImage: () => previewImage,
		saveImageToPhotosAlbum: () => saveImageToPhotosAlbum
	});
	/**
	* 保存图片到系统相册
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.saveImageToPhotosAlbum.html
	*/
	function saveImageToPhotosAlbum(opts) {
		invokeAPI("saveImageToPhotosAlbum", opts);
	}
	/**
	* 在新页面中全屏预览图片
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.previewImage.html
	*/
	function previewImage(opts) {
		invokeAPI("previewImage", opts);
	}
	/**
	* 压缩图片接口，可选压缩质量。
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.compressImage.html
	*/
	function compressImage(opts) {
		invokeAPI("compressImage", opts);
	}
	/**
	* 从本地相册选择图片或使用相机拍照。
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.chooseImage.html
	*/
	function chooseImage(opts) {
		invokeAPI("chooseImage", opts);
	}
	//#endregion
	//#region src/api/core/media/video/index.js
	var video_exports = /* @__PURE__ */ __exportAll({
		chooseMedia: () => chooseMedia,
		chooseVideo: () => chooseVideo
	});
	/**
	* 拍摄视频或从手机相册中选视频
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/video/wx.chooseVideo.html
	*/
	function chooseVideo(opts) {
		invokeAPI("chooseVideo", opts);
	}
	/**
	* 拍摄或从手机相册中选择图片或视频
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/video/wx.chooseMedia.html
	*/
	function chooseMedia(opts) {
		invokeAPI("chooseMedia", opts);
	}
	//#endregion
	//#region src/api/core/navigate/index.js
	var navigate_exports = /* @__PURE__ */ __exportAll({
		exitMiniProgram: () => exitMiniProgram,
		navigateBackMiniProgram: () => navigateBackMiniProgram,
		navigateToMiniProgram: () => navigateToMiniProgram,
		restartMiniProgram: () => restartMiniProgram
	});
	/**
	* 重启当前小程序
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.restartMiniProgram.html
	*/
	function restartMiniProgram(opts) {
		invokeAPI("restartMiniProgram", opts);
	}
	/**
	* 打开另一个小程序
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.navigateToMiniProgram.html
	*/
	function navigateToMiniProgram(opts) {
		invokeAPI("navigateToMiniProgram", opts);
	}
	/**
	* 返回到上一个小程序。只有在当前小程序是被其他小程序打开时可以调用成功
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.navigateBackMiniProgram.html
	*/
	function navigateBackMiniProgram(opts) {
		invokeAPI("navigateBackMiniProgram", opts);
	}
	/**
	* 退出当前小程序。必须有点击行为才能调用成功
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.exitMiniProgram.html
	*/
	function exitMiniProgram(opts) {
		invokeAPI("exitMiniProgram", opts);
	}
	//#endregion
	//#region src/api/core/network/download/index.js
	var download_exports = /* @__PURE__ */ __exportAll({ downloadFile: () => downloadFile });
	/**
	* 下载文件资源到本地
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/download/wx.downloadFile.html
	* @param {*} opts
	*/
	function downloadFile(opts) {
		invokeAPI("downloadFile", opts);
	}
	//#endregion
	//#region src/api/core/network/request/index.js
	var request_exports = /* @__PURE__ */ __exportAll({ request: () => request });
	/**
	* 发起 HTTPS 网络请求
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/request/wx.request.html
	* @param {*} opts
	*/
	function request(opts) {
		invokeAPI("request", opts);
	}
	//#endregion
	//#region src/api/core/network/upload/index.js
	var upload_exports = /* @__PURE__ */ __exportAll({ uploadFile: () => uploadFile });
	/**
	*将本地资源上传到服务器
	*https://developers.weixin.qq.com/miniprogram/dev/api/network/upload/wx.uploadFile.html
	*/
	function uploadFile(opts) {
		invokeAPI("uploadFile", opts);
	}
	//#endregion
	//#region src/api/core/network/websocket/index.js
	var websocket_exports = /* @__PURE__ */ __exportAll({
		closeSocket: () => closeSocket,
		connectSocket: () => connectSocket,
		onSocketClose: () => onSocketClose,
		onSocketError: () => onSocketError,
		onSocketMessage: () => onSocketMessage,
		onSocketOpen: () => onSocketOpen,
		sendSocketMessage: () => sendSocketMessage
	});
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/websocket/SocketTask.html
	* SocketTask 类，用于管理 WebSocket 连接
	*/
	var SocketTask = class {
		constructor(socketId) {
			this.socketId = socketId;
			this._readyState = 0;
		}
		/**
		* 通过 WebSocket 连接发送数据
		* @param {Object} opts 
		*/
		send(opts = {}) {
			const { data, success, fail, complete, ...rest } = opts;
			const params = {
				socketId: this.socketId,
				data,
				...rest
			};
			if (isFunction(success)) params.success = callback_default.store(success);
			if (isFunction(fail)) params.fail = callback_default.store(fail);
			if (isFunction(complete)) params.complete = callback_default.store(complete);
			return invokeAPI("sendSocketMessage", params);
		}
		/**
		* 关闭 WebSocket 连接
		* @param {Object} opts 
		*/
		close(opts = {}) {
			const { code = 1e3, reason = "", success, fail, complete, ...rest } = opts;
			const params = {
				socketId: this.socketId,
				code,
				reason,
				...rest
			};
			if (isFunction(success)) params.success = callback_default.store(success);
			if (isFunction(fail)) params.fail = callback_default.store(fail);
			if (isFunction(complete)) params.complete = callback_default.store(complete);
			return invokeAPI("closeSocket", params);
		}
		/**
		* 监听 WebSocket 连接打开事件
		* @param {Function} callback 回调函数
		*/
		onOpen(callbackFn) {
			if (isFunction(callbackFn)) return invokeAPI("onSocketOpen", {
				socketId: this.socketId,
				callback: callback_default.store(callbackFn, true)
			});
		}
		/**
		* 取消监听 WebSocket 连接打开事件
		* @param {Function} callback 回调函数
		*/
		offOpen(callbackFn) {
			return invokeAPI("offSocketOpen", {
				socketId: this.socketId,
				callback: callbackFn
			});
		}
		/**
		* 监听 WebSocket 接受到服务器的消息事件
		* @param {Function} callback 回调函数
		*/
		onMessage(callbackFn) {
			if (isFunction(callbackFn)) return invokeAPI("onSocketMessage", {
				socketId: this.socketId,
				callback: callback_default.store(callbackFn, true)
			});
		}
		/**
		* 取消监听 WebSocket 接受到服务器的消息事件
		* @param {Function} callback 回调函数
		*/
		offMessage(callbackFn) {
			return invokeAPI("offSocketMessage", {
				socketId: this.socketId,
				callback: callbackFn
			});
		}
		/**
		* 监听 WebSocket 错误事件
		* @param {Function} callback 回调函数
		*/
		onError(callbackFn) {
			if (isFunction(callbackFn)) return invokeAPI("onSocketError", {
				socketId: this.socketId,
				callback: callback_default.store(callbackFn, true)
			});
		}
		/**
		* 取消监听 WebSocket 错误事件
		* @param {Function} callback 回调函数
		*/
		offError(callbackFn) {
			return invokeAPI("offSocketError", {
				socketId: this.socketId,
				callback: callbackFn
			});
		}
		/**
		* 监听 WebSocket 连接关闭事件
		* @param {Function} callback 回调函数
		*/
		onClose(callbackFn) {
			if (isFunction(callbackFn)) return invokeAPI("onSocketClose", {
				socketId: this.socketId,
				callback: callback_default.store(callbackFn, true)
			});
		}
		/**
		* 取消监听 WebSocket 连接关闭事件
		* @param {Function} callback 回调函数
		*/
		offClose(callbackFn) {
			return invokeAPI("offSocketClose", {
				socketId: this.socketId,
				callback: callbackFn
			});
		}
		/**
		* 获取 WebSocket 连接状态
		* @returns {number} 连接状态
		*/
		get readyState() {
			return this._readyState;
		}
		/**
		* WebSocket 的连接状态常量
		*/
		static get CONNECTING() {
			return 0;
		}
		static get OPEN() {
			return 1;
		}
		static get CLOSING() {
			return 2;
		}
		static get CLOSED() {
			return 3;
		}
	};
	/**
	* 创建一个 WebSocket 连接
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/websocket/wx.connectSocket.html
	* @param {Object} opts 配置对象
	* @param {string} opts.url 开发者服务器 wss 接口地址
	* @param {Object} [opts.header] HTTP Header，Header 中不能设置 Referer
	* @param {Array<string>} [opts.protocols] 子协议数组
	* @param {boolean} [opts.tcpNoDelay] 建立 TCP 连接的时候的 TCP_NODELAY 设置
	* @param {boolean} [opts.perMessageDeflate] 是否开启压缩扩展
	* @param {number} [opts.timeout] 超时时间，单位为毫秒
	* @param {boolean} [opts.forceCellularNetwork] 强制使用蜂窝网络发送请求
	* @param {Function} [opts.success] 接口调用成功的回调函数
	* @param {Function} [opts.fail] 接口调用失败的回调函数
	* @param {Function} [opts.complete] 接口调用结束的回调函数（调用成功、失败都会执行）
	* @returns {SocketTask} WebSocket 任务对象
	*/
	function connectSocket(opts = {}) {
		const { url, header = {}, protocols = [], tcpNoDelay = false, perMessageDeflate = false, timeout, forceCellularNetwork = false, success, fail, complete, ...rest } = opts;
		if (!url) {
			const error = /* @__PURE__ */ new Error("url is required");
			if (isFunction(fail)) fail(error);
			if (isFunction(complete)) complete(error);
			throw error;
		}
		const socketId = `socket_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
		const socketTask = new SocketTask(socketId);
		const params = {
			socketId,
			url,
			header,
			protocols,
			tcpNoDelay,
			perMessageDeflate,
			timeout,
			forceCellularNetwork,
			...rest
		};
		if (isFunction(success)) params.success = callback_default.store((res) => {
			socketTask._readyState = SocketTask.OPEN;
			success(res);
		});
		if (isFunction(fail)) params.fail = callback_default.store((error) => {
			socketTask._readyState = SocketTask.CLOSED;
			fail(error);
		});
		if (isFunction(complete)) params.complete = callback_default.store(complete);
		invokeAPI("connectSocket", params);
		return socketTask;
	}
	/**
	* 通过 WebSocket 连接发送数据（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Object} opts 
	*/
	function sendSocketMessage(opts) {
		return invokeAPI("sendSocketMessage", opts);
	}
	/**
	* 关闭 WebSocket 连接（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Object} opts 
	*/
	function closeSocket(opts) {
		return invokeAPI("closeSocket", opts);
	}
	/**
	* 监听 WebSocket 连接打开事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketOpen(callbackFn) {
		return invokeAPI("onSocketOpen", { callback: callback_default.store(callbackFn, true) });
	}
	/**
	* 监听 WebSocket 接受到服务器的消息事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketMessage(callbackFn) {
		return invokeAPI("onSocketMessage", { callback: callback_default.store(callbackFn, true) });
	}
	/**
	* 监听 WebSocket 错误事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketError(callbackFn) {
		return invokeAPI("onSocketError", { callback: callback_default.store(callbackFn, true) });
	}
	/**
	* 监听 WebSocket 连接关闭事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketClose(callbackFn) {
		return invokeAPI("onSocketClose", { callback: callback_default.store(callbackFn, true) });
	}
	//#endregion
	//#region src/api/core/open-api/account-info/index.js
	var account_info_exports = /* @__PURE__ */ __exportAll({ getAccountInfoSync: () => getAccountInfoSync });
	/**
	* 获取当前账号信息
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/account-info/wx.getAccountInfoSync.html
	*/
	function getAccountInfoSync() {
		return invokeAPI("getAccountInfoSync");
	}
	//#endregion
	//#region src/api/core/open-api/authorize/index.js
	var authorize_exports = /* @__PURE__ */ __exportAll({ authorize: () => authorize });
	/**
	* 提前向用户发起授权请求。调用后会立刻弹窗询问用户是否同意授权小程序使用某项功能或获取用户的某些数据，但不会实际调用对应接口。如果用户之前已经同意授权，则不会出现弹窗，直接返回成功。
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/authorize/wx.authorize.html
	*/
	function authorize(opts) {
		invokeAPI("authorize", opts);
	}
	//#endregion
	//#region src/api/core/open-api/index.js
	var open_api_exports = /* @__PURE__ */ __exportAll({ login: () => login$1 });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/login/wx.login.html
	*/
	function login$1(opts) {
		invokeAPI("login", opts);
	}
	//#endregion
	//#region src/api/core/open-api/login/index.js
	var login_exports = /* @__PURE__ */ __exportAll({ login: () => login });
	/**
	* 调用接口获取登录凭证
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/login/wx.login.html
	* @param {*} opts
	*/
	function login(opts) {
		invokeAPI("login", opts);
	}
	//#endregion
	//#region src/api/core/open-api/privacy/index.js
	var privacy_exports = /* @__PURE__ */ __exportAll({ getPrivacySetting: () => getPrivacySetting });
	function getPrivacySetting(opts) {
		invokeAPI("getPrivacySetting", opts);
	}
	//#endregion
	//#region src/api/core/open-api/setting/index.js
	var setting_exports = /* @__PURE__ */ __exportAll({
		getSetting: () => getSetting,
		openSetting: () => openSetting
	});
	/**
	* 调起客户端小程序设置界面，返回用户设置的操作结果
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/setting/wx.openSetting.html
	*/
	function openSetting(opts) {
		invokeAPI("openSetting", opts);
	}
	/**
	* 获取用户的当前设置
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/setting/wx.getSetting.html
	*/
	function getSetting(opts) {
		invokeAPI("getSetting", opts);
	}
	//#endregion
	//#region src/api/core/open-api/user-info/index.js
	var user_info_exports = /* @__PURE__ */ __exportAll({ getUserInfo: () => getUserInfo });
	/**
	* 获取用户信息
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/user-info/wx.getUserInfo.html
	* @param {*} opts
	*/
	function getUserInfo(opts) {
		invokeAPI("getUserInfo", opts);
	}
	//#endregion
	//#region src/api/core/payment/index.js
	var payment_exports = /* @__PURE__ */ __exportAll({ requestPayment: () => requestPayment });
	/**
	* 发起支付
	* https://developers.weixin.qq.com/miniprogram/dev/api/payment/wx.requestPayment.html
	*/
	function requestPayment(opts) {
		invokeAPI("requestPayment", opts);
	}
	//#endregion
	//#region src/api/core/share/index.js
	var share_exports = /* @__PURE__ */ __exportAll({
		hideShareMenu: () => hideShareMenu,
		showShareImageMenu: () => showShareImageMenu,
		showShareMenu: () => showShareMenu
	});
	/**
	* 显示当前页面的转发按钮
	* https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.showShareMenu.html
	*/
	function showShareMenu(opts) {
		invokeAPI("shareShareMenu", opts);
	}
	/**
	* 打开分享图片弹窗，可以将图片发送给朋友、收藏或下载
	* https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.showShareImageMenu.html
	*/
	function showShareImageMenu(opts) {
		invokeAPI("showShareImageMenu", opts);
	}
	/**
	* 隐藏当前页面的转发按钮
	* https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.hideShareMenu.html
	*/
	function hideShareMenu(opts) {
		invokeAPI("hideShareMenu", opts);
	}
	//#endregion
	//#region src/api/core/storage/index.js
	var storage_exports = /* @__PURE__ */ __exportAll({
		clearStorage: () => clearStorage,
		clearStorageSync: () => clearStorageSync,
		getStorage: () => getStorage,
		getStorageInfo: () => getStorageInfo,
		getStorageInfoSync: () => getStorageInfoSync,
		getStorageSync: () => getStorageSync,
		removeStorage: () => removeStorage,
		removeStorageSync: () => removeStorageSync,
		setStorage: () => setStorage,
		setStorageSync: () => setStorageSync
	});
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.setStorageSync.html
	*/
	function setStorageSync(...opts) {
		invokeAPI("setStorageSync", opts);
	}
	/**
	* 从本地缓存中同步获取指定 key 的内容。
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorageSync.html
	*/
	function getStorageSync(opts) {
		return invokeAPI("getStorageSync", opts);
	}
	/**
	*
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.removeStorageSync.html
	*/
	function removeStorageSync(opts) {
		return invokeAPI("removeStorageSync", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.clearStorageSync.html
	*/
	function clearStorageSync() {
		invokeAPI("clearStorageSync");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.setStorage.html
	*/
	function setStorage(opts) {
		invokeAPI("setStorage", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorage.html
	*/
	function getStorage(opts) {
		invokeAPI("getStorage", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.removeStorage.html
	*/
	function removeStorage(opts) {
		invokeAPI("removeStorage", opts);
	}
	function clearStorage() {
		invokeAPI("clearStorage");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorageInfoSync.html
	*/
	function getStorageInfoSync() {
		return invokeAPI("getStorageInfoSync");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorageInfo.html
	*/
	function getStorageInfo(opts) {
		invokeAPI("getStorageInfo", opts);
	}
	//#endregion
	//#region src/api/core/ui/animation/index.js
	var animation_exports = /* @__PURE__ */ __exportAll({ createAnimation: () => createAnimation });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/wx.createAnimation.html
	* @returns { Animation } 动画对象
	*/
	function createAnimation(opts = {}) {
		return new Animation(opts);
	}
	var Animation = class {
		constructor({ duration = 400, timingFunction = "linear", delay = 0, transformOrigin = "50% 50% 0" } = {}) {
			this.actions = [];
			this.currentTransform = {};
			this.currentStepAnimates = [];
			this.option = {
				transition: {
					duration,
					timingFunction,
					delay
				},
				transformOrigin
			};
		}
		/**
		* 导出动画队列。export 方法每次调用后会清掉之前的动画操作。
		* https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.export.html
		*/
		export() {
			const actions = this.actions;
			this.actions = [];
			return { actions };
		}
		/**
		* 表示一组动画完成。可以在一组动画中调用任意多个动画方法，一组动画中的所有动画会同时开始，一组动画完成后才会进行下一组动画。
		* https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.step.html
		*/
		step(option = {}) {
			for (const stepAnimate of this.currentStepAnimates) if (stepAnimate.type === "style") this.currentTransform[`${stepAnimate.type}.${stepAnimate.args[0]}`] = stepAnimate;
			else this.currentTransform[stepAnimate.type] = stepAnimate;
			this.actions.push({
				animates: Object.keys(this.currentTransform).reduce((prev, current) => {
					return [].concat(...prev, [this.currentTransform[current]]);
				}, []),
				option: {
					transformOrigin: option.transformOrigin !== void 0 ? option.transformOrigin : this.option.transformOrigin,
					transition: {
						duration: option.duration !== void 0 ? option.duration : this.option.transition.duration,
						timingFunction: option.timingFunction !== void 0 ? option.timingFunction : this.option.transition.timingFunction,
						delay: option.delay !== void 0 ? option.delay : this.option.transition.delay
					}
				}
			});
			this.currentStepAnimates = [];
			return this;
		}
		backgroundColor(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["background-color", value]
			});
			return this;
		}
		bottom(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["bottom", suffixPixel(value)]
			});
			return this;
		}
		height(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["height", suffixPixel(value)]
			});
			return this;
		}
		left(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["left", suffixPixel(value)]
			});
			return this;
		}
		matrix(a = 1, b = 0, c = 0, d = 1, tx = 1, ty = 1) {
			this.currentStepAnimates.push({
				type: "matrix",
				args: [
					a,
					b,
					c,
					d,
					tx,
					ty
				]
			});
			return this;
		}
		matrix3d(a1 = 1, b1 = 0, c1 = 0, d1 = 0, a2 = 0, b2 = 1, c2 = 0, d2 = 0, a3 = 0, b3 = 0, c3 = 1, d3 = 0, a4 = 0, b4 = 0, c4 = 0, d4 = 1) {
			this.currentStepAnimates.push({
				type: "matrix3d",
				args: [
					a1,
					b1,
					c1,
					d1,
					a2,
					b2,
					c2,
					d2,
					a3,
					b3,
					c3,
					d3,
					a4,
					b4,
					c4,
					d4
				]
			});
			return this;
		}
		opacity(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["opacity", value]
			});
			return this;
		}
		right(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["right", suffixPixel(value)]
			});
			return this;
		}
		rotate(angle = 0) {
			this.currentStepAnimates.push({
				type: "rotate",
				args: [angle]
			});
			return this;
		}
		rotate3d(x = 0, y = 0, z = 0, angle = 0) {
			this.currentStepAnimates.push({
				type: "rotate3d",
				args: [
					x,
					y,
					z,
					angle
				]
			});
			return this;
		}
		rotateX(angle) {
			this.currentStepAnimates.push({
				type: "rotateX",
				args: [angle]
			});
			return this;
		}
		rotateY(angle) {
			this.currentStepAnimates.push({
				type: "rotateY",
				args: [angle]
			});
			return this;
		}
		rotateZ(angle) {
			this.currentStepAnimates.push({
				type: "rotateZ",
				args: [angle]
			});
			return this;
		}
		scale(x = 1, y = 1) {
			this.currentStepAnimates.push({
				type: "scale",
				args: [x, y]
			});
			return this;
		}
		scale3d(sx = 1, sy = 1, sz = 1) {
			this.currentStepAnimates.push({
				type: "scale3d",
				args: [
					sx,
					sy,
					sz
				]
			});
			return this;
		}
		scaleX(scale = 1) {
			this.currentStepAnimates.push({
				type: "scaleX",
				args: [scale]
			});
			return this;
		}
		scaleY(scale = 1) {
			this.currentStepAnimates.push({
				type: "scaleY",
				args: [scale]
			});
			return this;
		}
		scaleZ(scale = 1) {
			this.currentStepAnimates.push({
				type: "scaleZ",
				args: [scale]
			});
			return this;
		}
		skew(ax = 0, ay = 0) {
			this.currentStepAnimates.push({
				type: "skew",
				args: [ax, ay]
			});
			return this;
		}
		skewX(angle = 0) {
			this.currentStepAnimates.push({
				type: "skewX",
				args: [angle]
			});
			return this;
		}
		skewY(angle = 0) {
			this.currentStepAnimates.push({
				type: "skewY",
				args: [angle]
			});
			return this;
		}
		top(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["top", suffixPixel(value)]
			});
			return this;
		}
		translate(tx = 0, ty = 0) {
			this.currentStepAnimates.push({
				type: "translate",
				args: [tx, ty]
			});
			return this;
		}
		translate3d(tx = 0, ty = 0, tz = 0) {
			this.currentStepAnimates.push({
				type: "translate3d",
				args: [
					tx,
					ty,
					tz
				]
			});
			return this;
		}
		translateX(translation = 0) {
			this.currentStepAnimates.push({
				type: "translateX",
				args: [translation]
			});
			return this;
		}
		translateY(translation = 0) {
			this.currentStepAnimates.push({
				type: "translateY",
				args: [translation]
			});
			return this;
		}
		width(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["width", suffixPixel(value)]
			});
			return this;
		}
	};
	//#endregion
	//#region src/api/core/ui/background/index.js
	var background_exports = /* @__PURE__ */ __exportAll({
		setBackgroundColor: () => setBackgroundColor,
		setBackgroundTextStyle: () => setBackgroundTextStyle
	});
	/**
	* 动态设置下拉背景字体、loading 图的样式
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/background/wx.setBackgroundTextStyle.html
	*/
	function setBackgroundTextStyle(opts) {
		invokeAPI("setBackgroundTextStyle", opts);
	}
	/**
	* 动态设置窗口的背景色
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/background/wx.setBackgroundColor.html
	*/
	function setBackgroundColor(opts) {
		invokeAPI("setBackgroundColor", opts);
	}
	//#endregion
	//#region src/api/core/ui/canvas/index.js
	var canvas_exports = /* @__PURE__ */ __exportAll({
		canvasToTempFilePath: () => canvasToTempFilePath,
		createCanvasContext: () => createCanvasContext,
		createContext: () => createContext,
		drawCanvas: () => drawCanvas
	});
	/**
	* 创建绘图上下文
	* 兼容旧版 wx.createContext。
	*/
	function createContext() {
		return new CanvasContext();
	}
	/**
	* 创建 canvas 的绘图上下文
	* https://developers.weixin.qq.com/miniprogram/dev/api/canvas/wx.createCanvasContext.html
	*/
	function createCanvasContext(canvasId, component) {
		return new CanvasContext(canvasId, resolveModuleId(component));
	}
	/**
	* 兼容旧版 wx.drawCanvas。
	*/
	function drawCanvas(opts = {}) {
		const params = {
			...opts,
			moduleId: opts.moduleId || resolveModuleId(opts.component)
		};
		delete params.component;
		invokeAPI("drawCanvas", params, "render");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/canvas/wx.canvasToTempFilePath.html
	*/
	function canvasToTempFilePath(opts = {}, component) {
		const params = {
			...opts,
			moduleId: opts.moduleId || resolveModuleId(component || opts.component)
		};
		delete params.component;
		invokeAPI("canvasToTempFilePath", params, "render");
	}
	function resolveModuleId(component) {
		return component?.__id__ || router_default.getPageInfo()?.id;
	}
	var CanvasContext = class {
		constructor(canvasId = "", moduleId = null) {
			this.canvasId = canvasId;
			this.moduleId = moduleId;
			this.actions = [];
		}
		pushAction(type, ...args) {
			this.actions.push({
				type,
				args
			});
			return this;
		}
		getActions() {
			return this.actions.slice();
		}
		draw(reserve = false, callback) {
			if (!this.canvasId) return;
			drawCanvas({
				canvasId: this.canvasId,
				moduleId: this.moduleId,
				actions: this.getActions(),
				reserve,
				success: callback
			});
			this.actions = [];
		}
		beginPath() {
			return this.pushAction("beginPath");
		}
		closePath() {
			return this.pushAction("closePath");
		}
		moveTo(x, y) {
			return this.pushAction("moveTo", x, y);
		}
		lineTo(x, y) {
			return this.pushAction("lineTo", x, y);
		}
		rect(x, y, width, height) {
			return this.pushAction("rect", x, y, width, height);
		}
		arc(x, y, radius, startAngle, endAngle, counterclockwise = false) {
			return this.pushAction("arc", x, y, radius, startAngle, endAngle, counterclockwise);
		}
		quadraticCurveTo(cpx, cpy, x, y) {
			return this.pushAction("quadraticCurveTo", cpx, cpy, x, y);
		}
		bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) {
			return this.pushAction("bezierCurveTo", cp1x, cp1y, cp2x, cp2y, x, y);
		}
		fill() {
			return this.pushAction("fill");
		}
		stroke() {
			return this.pushAction("stroke");
		}
		clearRect(x, y, width, height) {
			return this.pushAction("clearRect", x, y, width, height);
		}
		fillText(text, x, y, maxWidth) {
			return this.pushAction("fillText", text, x, y, maxWidth);
		}
		drawImage(src, ...rest) {
			return this.pushAction("drawImage", src, ...rest);
		}
		save() {
			return this.pushAction("save");
		}
		restore() {
			return this.pushAction("restore");
		}
		translate(x, y) {
			return this.pushAction("translate", x, y);
		}
		rotate(angle) {
			return this.pushAction("rotate", angle);
		}
		scale(x, y) {
			return this.pushAction("scale", x, y);
		}
		setShadow(offsetX, offsetY, blur, color) {
			return this.pushAction("setShadow", offsetX, offsetY, blur, color);
		}
		setFillStyle(value) {
			return this.pushAction("setFillStyle", value);
		}
		setStrokeStyle(value) {
			return this.pushAction("setStrokeStyle", value);
		}
		setGlobalAlpha(value) {
			return this.pushAction("setGlobalAlpha", value);
		}
		setLineCap(value) {
			return this.pushAction("setLineCap", value);
		}
		setLineJoin(value) {
			return this.pushAction("setLineJoin", value);
		}
		setLineWidth(value) {
			return this.pushAction("setLineWidth", value);
		}
		setMiterLimit(value) {
			return this.pushAction("setMiterLimit", value);
		}
		setFontSize(value) {
			return this.pushAction("setFontSize", value);
		}
	};
	//#endregion
	//#region src/api/core/ui/custom-component/index.js
	var custom_component_exports = /* @__PURE__ */ __exportAll({ nextTick: () => nextTick });
	var nextTickCallbackList = [];
	var nextTickTimer = null;
	function callNextTick() {
		const cbs = nextTickCallbackList;
		nextTickCallbackList = [];
		nextTickTimer = null;
		for (let i = 0; i < cbs.length; i++) cbs[i]();
	}
	/**
	* 延迟一部分操作到下一个时间片再执行
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/custom-component/wx.nextTick.html
	*/
	function nextTick(callback) {
		if (isFunction(callback)) {
			nextTickCallbackList.push(callback);
			if (!nextTickTimer) nextTickTimer = setTimeout(callNextTick, 0);
		}
	}
	//#endregion
	//#region src/api/core/ui/interaction/index.js
	var interaction_exports = /* @__PURE__ */ __exportAll({
		disableAlertBeforeUnload: () => disableAlertBeforeUnload,
		enableAlertBeforeUnload: () => enableAlertBeforeUnload,
		hideLoading: () => hideLoading,
		hideToast: () => hideToast,
		showActionSheet: () => showActionSheet,
		showLoading: () => showLoading,
		showModal: () => showModal,
		showToast: () => showToast
	});
	/**
	* 显示消息提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showToast.html
	*/
	function showToast(opts) {
		invokeAPI("showToast", opts);
	}
	/**
	* 隐藏消息提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.hideToast.html
	*/
	function hideToast(opts) {
		invokeAPI("hideToast", opts);
	}
	/**
	* 显示模态对话框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showModal.html
	*/
	function showModal(opts) {
		invokeAPI("showModal", opts);
	}
	/**
	* 显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showLoading.html
	*/
	function showLoading(opts) {
		invokeAPI("showLoading", opts);
	}
	/**
	* 显示操作菜单
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showActionSheet.html
	*/
	function showActionSheet(opts) {
		invokeAPI("showActionSheet", opts);
	}
	/**
	* 隐藏 loading 提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.hideLoading.html
	*/
	function hideLoading(opts) {
		invokeAPI("hideLoading", opts);
	}
	/**
	* 开启小程序页面返回询问对话框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.enableAlertBeforeUnload.html
	*/
	function enableAlertBeforeUnload(opts) {
		invokeAPI("enableAlertBeforeUnload", opts);
	}
	/**
	* 关闭小程序页面返回询问对话框
	*/
	function disableAlertBeforeUnload(opts) {
		invokeAPI("disableAlertBeforeUnload", opts);
	}
	//#endregion
	//#region src/api/core/ui/menu/index.js
	var menu_exports = /* @__PURE__ */ __exportAll({
		getMenuButtonBoundingClientRect: () => getMenuButtonBoundingClientRect,
		offMenuButtonBoundingClientRectWeightChange: () => offMenuButtonBoundingClientRectWeightChange,
		onMenuButtonBoundingClientRectWeightChange: () => onMenuButtonBoundingClientRectWeightChange
	});
	var menuRectChangeCallbacks = /* @__PURE__ */ new Set();
	/**
	* 获取菜单按钮（右上角胶囊按钮）的布局位置信息。坐标信息以屏幕左上角为原点。
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/menu/wx.getMenuButtonBoundingClientRect.html
	*/
	function getMenuButtonBoundingClientRect() {
		return invokeAPI("getMenuButtonBoundingClientRect");
	}
	function onMenuButtonBoundingClientRectWeightChange(callback) {
		if (isFunction(callback)) menuRectChangeCallbacks.add(callback);
	}
	function offMenuButtonBoundingClientRectWeightChange(callback) {
		if (isFunction(callback)) menuRectChangeCallbacks.delete(callback);
		else menuRectChangeCallbacks.clear();
	}
	//#endregion
	//#region src/api/core/ui/navigation-bar/index.js
	var navigation_bar_exports = /* @__PURE__ */ __exportAll({
		hideNavigationBarLoading: () => hideNavigationBarLoading,
		setNavigationBarColor: () => setNavigationBarColor,
		setNavigationBarTitle: () => setNavigationBarTitle,
		showNavigationBarLoading: () => showNavigationBarLoading
	});
	/**
	* 在当前页面显示导航条加载动画
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.showNavigationBarLoading.html
	*/
	function showNavigationBarLoading(opts) {
		invokeAPI("showNavigationBarLoading", opts);
	}
	/**
	* 动态设置当前页面的标题
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.setNavigationBarTitle.html
	*/
	function setNavigationBarTitle(opts) {
		invokeAPI("setNavigationBarTitle", opts);
	}
	/**
	* 设置页面导航条颜色
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.setNavigationBarColor.html
	*/
	function setNavigationBarColor(opts) {
		invokeAPI("setNavigationBarColor", opts);
	}
	/**
	* 在当前页面隐藏导航条加载动画
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.hideNavigationBarLoading.html
	*/
	function hideNavigationBarLoading(opts) {
		invokeAPI("hideNavigationBarLoading", opts);
	}
	//#endregion
	//#region src/api/core/ui/pull-down-refresh/index.js
	var pull_down_refresh_exports = /* @__PURE__ */ __exportAll({
		startPullDownRefresh: () => startPullDownRefresh,
		stopPullDownRefresh: () => stopPullDownRefresh
	});
	/**
	* 停止当前页面下拉刷新
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/pull-down-refresh/wx.stopPullDownRefresh.html
	*/
	function stopPullDownRefresh(opts) {
		invokeAPI("stopPullDownRefresh", opts);
	}
	/**
	*	开始下拉刷新。调用后触发下拉刷新动画，效果与用户手动下拉刷新一致
	*	https://developers.weixin.qq.com/miniprogram/dev/api/ui/pull-down-refresh/wx.startPullDownRefresh.html
	*/
	function startPullDownRefresh(opts) {
		invokeAPI("startPullDownRefresh", opts);
	}
	//#endregion
	//#region src/api/core/ui/scroll/index.js
	var scroll_exports = /* @__PURE__ */ __exportAll({ pageScrollTo: () => pageScrollTo });
	/**
	* 界面 / 滚动 / wx.pageScrollTo
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/scroll/wx.pageScrollTo.html
	*/
	function pageScrollTo(opts) {
		invokeAPI("pageScrollTo", opts);
	}
	//#endregion
	//#region src/api/core/ui/tab-bar/index.js
	var tab_bar_exports = /* @__PURE__ */ __exportAll({
		hideTabBar: () => hideTabBar,
		hideTabBarRedDot: () => hideTabBarRedDot,
		removeTabBarBadge: () => removeTabBarBadge,
		setTabBarBadge: () => setTabBarBadge,
		setTabBarItem: () => setTabBarItem,
		setTabBarStyle: () => setTabBarStyle,
		showTabBar: () => showTabBar,
		showTabBarRedDot: () => showTabBarRedDot
	});
	/**
	* 动态设置 tabBar 整体样式
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.setTabBarStyle.html
	*/
	function setTabBarStyle(opts) {
		invokeAPI("setTabBarStyle", opts);
	}
	/**
	* 动态设置 tabBar 某一项的内容
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.setTabBarItem.html
	*/
	function setTabBarItem(opts) {
		invokeAPI("setTabBarItem", opts);
	}
	/**
	* 显示 tabBar
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.showTabBar.html
	*/
	function showTabBar(opts) {
		invokeAPI("showTabBar", opts);
	}
	/**
	* 隐藏 tabBar
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.hideTabBar.html
	*/
	function hideTabBar(opts) {
		invokeAPI("hideTabBar", opts);
	}
	/**
	* 为 tabBar 某一项的右上角添加文本
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.setTabBarBadge.html
	*/
	function setTabBarBadge(opts) {
		invokeAPI("setTabBarBadge", opts);
	}
	/**
	* 移除 tabBar 某一项右上角的文本
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.removeTabBarBadge.html
	*/
	function removeTabBarBadge(opts) {
		invokeAPI("removeTabBarBadge", opts);
	}
	/**
	* 显示 tabBar 某一项右上角的红点
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.showTabBarRedDot.html
	*/
	function showTabBarRedDot(opts) {
		invokeAPI("showTabBarRedDot", opts);
	}
	/**
	* 隐藏 tabBar 某一项右上角的红点
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.hideTabBarRedDot.html
	*/
	function hideTabBarRedDot(opts) {
		invokeAPI("hideTabBarRedDot", opts);
	}
	//#endregion
	//#region src/api/core/ui/window/index.js
	var window_exports = /* @__PURE__ */ __exportAll({ onWindowResize: () => onWindowResize });
	/**
	* 监听窗口尺寸变化事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/window/wx.onWindowResize.html
	*/
	function onWindowResize(listener) {
		if (listener) invokeAPI("onWindowResize", { success: listener });
	}
	//#endregion
	//#region src/api/index.js
	var apiInfo = /* @__PURE__ */ Object.assign({
		"./core/base/app-event/index.js": app_event_exports,
		"./core/base/index.js": base_exports,
		"./core/base/performance/index.js": performance_exports,
		"./core/base/subpackage/index.js": subpackage_exports,
		"./core/base/system/index.js": system_exports,
		"./core/base/update/index.js": update_exports,
		"./core/camera/index.js": camera_exports,
		"./core/data-analysis/index.js": data_analysis_exports,
		"./core/device/bluetooth/index.js": bluetooth_exports,
		"./core/device/bluetooth-ble/index.js": bluetooth_ble_exports,
		"./core/device/clipboard/index.js": clipboard_exports,
		"./core/device/contact/index.js": contact_exports,
		"./core/device/keyboard/index.js": keyboard_exports,
		"./core/device/memory/index.js": memory_exports,
		"./core/device/network/index.js": network_exports,
		"./core/device/phone/index.js": phone_exports,
		"./core/device/scan/index.js": scan_exports,
		"./core/device/vibrate/index.js": vibrate_exports,
		"./core/ext/index.js": ext_exports,
		"./core/file/index.js": file_exports,
		"./core/life-cycle/index.js": life_cycle_exports,
		"./core/location/index.js": location_exports,
		"./core/map/index.js": map_exports,
		"./core/media/image/index.js": image_exports,
		"./core/media/video/index.js": video_exports,
		"./core/navigate/index.js": navigate_exports,
		"./core/network/download/index.js": download_exports,
		"./core/network/request/index.js": request_exports,
		"./core/network/upload/index.js": upload_exports,
		"./core/network/websocket/index.js": websocket_exports,
		"./core/open-api/account-info/index.js": account_info_exports,
		"./core/open-api/authorize/index.js": authorize_exports,
		"./core/open-api/index.js": open_api_exports,
		"./core/open-api/login/index.js": login_exports,
		"./core/open-api/privacy/index.js": privacy_exports,
		"./core/open-api/setting/index.js": setting_exports,
		"./core/open-api/user-info/index.js": user_info_exports,
		"./core/payment/index.js": payment_exports,
		"./core/route/index.js": route_exports,
		"./core/share/index.js": share_exports,
		"./core/storage/index.js": storage_exports,
		"./core/ui/animation/index.js": animation_exports,
		"./core/ui/background/index.js": background_exports,
		"./core/ui/canvas/index.js": canvas_exports,
		"./core/ui/custom-component/index.js": custom_component_exports,
		"./core/ui/interaction/index.js": interaction_exports,
		"./core/ui/menu/index.js": menu_exports,
		"./core/ui/navigation-bar/index.js": navigation_bar_exports,
		"./core/ui/pull-down-refresh/index.js": pull_down_refresh_exports,
		"./core/ui/scroll/index.js": scroll_exports,
		"./core/ui/tab-bar/index.js": tab_bar_exports,
		"./core/ui/window/index.js": window_exports,
		"./core/wxml/intersection-observer/index.js": intersection_observer_exports,
		"./core/wxml/selector-query/index.js": selector_query_exports
	});
	var api = {};
	for (const f of Object.values(apiInfo)) for (const [k, v] of Object.entries(f)) api[k] = v;
	/**
	* 外部挂载 API，内部转发不存在 API
	* [Render]invokeAPI -> [Container]invokeAPI -> [Service]invokeAPI -> [Container]invokeAPI
	*/
	var globalApi = new Proxy(api, {
		get(target, prop, receiver) {
			const origMethod = Reflect.get(target, prop, receiver);
			if (typeof origMethod === "function") return origMethod;
			if (origMethod !== void 0 || prop === "webpackJsonp") return origMethod;
			return (...args) => {
				return invokeAPI(prop, ...args);
			};
		},
		set(target, prop, value, receiver) {
			return Reflect.set(target, prop, value, receiver);
		}
	});
	//#endregion
	//#region src/core/env.js
	var Env = class {
		constructor() {
			this.init();
		}
		init() {
			let customNamespaces = globalThis.__diminaApiNamespaces || [];
			if (customNamespaces.length === 0 && globalThis.name) try {
				customNamespaces = JSON.parse(globalThis.name).apiNamespaces || [];
			} catch (e) {}
			for (const name of [
				"dd",
				"wx",
				...customNamespaces
			]) globalThis[name] = globalApi;
			globalThis.modRequire = modRequire;
			globalThis.modDefine = modDefine;
			globalThis.global = {};
			/**
			* https://developers.weixin.qq.com/miniprogram/dev/framework/app-service/app.html
			*/
			globalThis.App = (moduleInfo) => loader_default.createAppModule(moduleInfo);
			globalThis.Page = (moduleInfo) => {
				loader_default.createModule(moduleInfo, globalThis.__extraInfo, PageModule.type);
			};
			globalThis.Component = (moduleInfo) => {
				loader_default.createModule(moduleInfo, globalThis.__extraInfo, ComponentModule.type);
			};
			/**
			* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Behavior.html
			*/
			globalThis.Behavior = (behaviorInfo) => {
				return behaviorInfo;
			};
			/**
			* 获取到小程序全局唯一的 App 实例
			* https://developers.weixin.qq.com/miniprogram/dev/reference/api/getApp.html
			*/
			globalThis.getApp = (options) => {
				const app = runtime_default.app;
				if (!app && options?.allowDefault) return {};
				return app;
			};
			/**
			* 获取当前页面栈。数组中第一个元素为首页，最后一个元素为当前页面
			* https://developers.weixin.qq.com/miniprogram/dev/reference/api/getCurrentPages.html
			*/
			globalThis.getCurrentPages = () => router_default.stack();
		}
	};
	var env_default = new Env();
	//#endregion
	//#region src/index.js
	var actionMap = {
		navigateBack,
		navigateTo,
		reLaunch,
		redirectTo,
		switchTab
	};
	/**
	* 逻辑层消息通道
	*/
	var Service = class {
		constructor() {
			console.log("[service] init");
			this.env = env_default;
			this.message = message_default;
			this.init();
		}
		init() {
			this.message.on("loadResource", (msg) => {
				const { appId, bridgeId, pagePath, root = ".", baseUrl = "/", hostEnv: hostEnvSnapshot } = msg;
				if (hostEnvSnapshot) host_env_default.init(hostEnvSnapshot);
				loader_default.loadResource({
					appId,
					bridgeId,
					pagePath,
					root,
					baseUrl
				});
			});
			this.message.on("t", async (msg) => {
				const { bridgeId, moduleId, methodName, event, success } = msg;
				if (methodName === void 0) return;
				const data = await runtime_default.triggerEvent({
					bridgeId,
					moduleId,
					methodName,
					event
				});
				if (data !== void 0) this.message.send({
					type: "triggerCallback",
					target: "render",
					body: {
						bridgeId,
						moduleId,
						success,
						data
					}
				});
			});
			this.message.on("triggerCallback", (msg) => {
				const { id, args } = msg;
				callback_default.invoke(id, args);
			});
			this.onAppMsg();
			this.onModuleMsg();
		}
		onAppMsg() {
			this.message.on("resourceLoaded", (msg) => {
				const { bridgeId, scene, pagePath, query, stackId } = msg;
				runtime_default.createApp({
					scene,
					pagePath,
					query
				});
				const module = loader_default.getModuleByPath(pagePath);
				if (!module) {
					console.error(`[service] resourceLoaded: module not found, pagePath: ${pagePath}`);
					return;
				}
				const initialProps = loader_default.getPropsByPath(module.usingComponents);
				const pageId = `page_${uuid()}`;
				runtime_default.createInstance({
					bridgeId,
					moduleId: pageId,
					path: pagePath,
					query,
					stackId
				});
				message_default.send({
					type: "firstRender",
					target: "render",
					body: {
						bridgeId,
						pageId,
						pagePath,
						initialProps,
						query
					}
				});
			});
			this.message.on("appShow", () => {
				runtime_default.appShow();
			});
			this.message.on("appHide", () => {
				runtime_default.appHide();
			});
			this.message.on("stackShow", ({ stackId }) => {
				runtime_default.stackShow(stackId);
			});
			this.message.on("stackHide", ({ stackId }) => {
				runtime_default.stackHide(stackId);
			});
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/app-service/page-life-cycle.html
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
		*/
		onModuleMsg() {
			this.message.on("mC", (msg) => {
				runtime_default.createInstance(msg);
			});
			this.message.on("mR", (msg) => {
				runtime_default.moduleReady(msg);
			});
			this.message.on("mU", (msg) => {
				runtime_default.moduleUnmounted(msg);
			});
			this.message.on("pageUnload", (msg) => {
				runtime_default.pageUnload(msg);
			});
			this.message.on("pageShow", (msg) => {
				runtime_default.pageShow(msg);
			});
			this.message.on("pageReady", (msg) => {
				runtime_default.pageReady(msg);
			});
			this.message.on("pageHide", (msg) => {
				runtime_default.pageHide(msg);
			});
			this.message.on("pagePullDownRefresh", () => {});
			this.message.on("pageReachBottom", () => {});
			this.message.on("pageShareAppMessage", () => {});
			this.message.on("pageScroll", (msg) => {
				runtime_default.pageScroll(msg);
			});
			this.message.on("pageResize", (msg) => {
				runtime_default.pageResize(msg);
			});
			this.message.on("onTabItemTap", () => {});
			this.message.on("pageRouteDone", (msg) => {
				const { bridgeId } = msg;
				runtime_default.componentRouteDone({ bridgeId });
			});
			this.message.on("componentError", (msg) => {
				runtime_default.componentError(msg);
			});
			this.message.on("h5SdkAction", async (msg = {}) => {
				const actionName = msg?.name?.replace(/h5/i, "");
				const { url } = msg?.params?.data?.params || {};
				msg.params && (msg.params.data = {
					...msg.params?.data,
					...msg.params?.data?.params || {}
				});
				if (actionName === "postMessage" && msg.parentWebViewId) {
					const { moduleId, attrs, params } = msg;
					const event = { detail: { data: [params?.data?.params?.data] } };
					const methodName = attrs.message;
					const parentWebViewId = msg.parentWebViewId;
					const data = await runtime_default.triggerEvent({
						bridgeId: parentWebViewId,
						moduleId,
						methodName,
						event
					});
					if (data !== void 0) this.message.send({
						type: "triggerCallback",
						target: "service",
						body: {
							bridgeId: parentWebViewId,
							moduleId,
							success: params?.success,
							data
						}
					});
				}
				actionMap[actionName]?.({
					url,
					...msg.params
				});
			});
		}
	};
	//#endregion
	return new Service();
})();
